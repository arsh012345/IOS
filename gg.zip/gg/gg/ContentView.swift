//
//  ContentView.swift
//  gg
//
//  Created by Arshdeep Singh on 2025-02-25.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
            Image(systemName: "globe")
                .imageScale(.large)
                .foregroundStyle(.tint)
            Text("Hello, world!").font(.custom("Delius-Regular", size: 20, relativeTo: .title))
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
