//
//  ggApp.swift
//  gg
//
//  Created by Arshdeep Singh on 2025-02-25.
//

import SwiftUI

@main
struct ggApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
