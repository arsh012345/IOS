//
//  AnimationsApp.swift
//  Animations
//
//  Created by Arshdeep Singh on 2025-04-06.
//

import SwiftUI

@main
struct AnimationsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
