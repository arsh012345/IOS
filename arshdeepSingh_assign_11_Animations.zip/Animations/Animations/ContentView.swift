//
//  ContentView.swift
//  Animations
//
//  Created by Arshdeep Singh on 2025-04-06.
//

import SwiftUI

struct ContentView: View {
    //@State private var animationAmount = 1.0
    //@State private var animationAmount = 0.0
    //@State private var enabled = false
    //@State private var dragAmount = CGSize.zero
    let letters = Array("Hello SwiftUI")
    
    @State private var enabled = false
    @State private var dragAmount = CGSize.zero
    
    var body: some View {
        HStack(spacing: 0){
            ForEach(0..<letters.count, id: \.self){ num in
                Text(String(letters[num]))
                    .padding(5)
                    .font(.title)
                    .background(enabled ? .blue : .red)
                    .offset(dragAmount)
                    .animation(.linear.delay(Double(num) / 20), value: dragAmount)
            }
        }
        .gesture(
            DragGesture()
                .onChanged{ dragAmount = $0.translation }
                .onEnded{ _ in
                    dragAmount = .zero
                    enabled.toggle()
                }
        )
        
        
        /*LinearGradient(colors: [.yellow, .red], startPoint: .topLeading, endPoint: .bottomTrailing)
         .frame(width: 300, height: 200)
         .clipShape(.rect(cornerRadius: 10))
         .offset(dragAmount)
         .gesture(
         DragGesture()
         .onChanged{ dragAmount = $0.translation }
         //.onEnded{ _ in dragAmount = .zero }
         .onEnded{ _ in
         withAnimation(.bouncy){
         dragAmount = .zero
         }
         }
         ) */
        //.animation(.bouncy, value: dragAmount)
        
        /*Button("Tap Me"){  controlling the animation stack advanced part:- 1
         enabled.toggle()
         }
         .frame(width: 200, height: 200)
         .background(enabled ? .blue : .red)
         .foregroundStyle(.white)
         //.animation(.default, value: enabled)
         .animation(nil, value: enabled)
         .clipShape(.rect(cornerRadius: enabled ? 60 : 0))
         .animation(.spring(duration: 1, bounce: 0.9), value: enabled)
         //.background(enabled ? .blue : .red)
         //.clipShape(.rect(cornerRadius: enabled ? 60 : 0))*/
        
        /*Button("Tap Me"){  creating explicit animation part:- 4
         withAnimation(.spring(duration: 1, bounce: 0.5)){
         animationAmount += 360
         }
         //withAnimation{animationAmount += 360}
         }
         .padding(50)
         .background(.red)
         .foregroundStyle(.white)
         .clipShape(.circle)
         .rotation3DEffect(.degrees(animationAmount), axis: (x: 0, y: 1, z: 0))
         //.rotation3DEffect(.degrees(animationAmount), axis: (x: 1, y: 1, z: 0))
         //.rotation3DEffect(.degrees(animationAmount), axis: (x: 0, y: 0, z: 1))
         */
        
        /*  animating bindings part:- 3
         print(animationAmount)
         
         return VStack{
         //Stepper("Scale amount", value: $animationAmount.animation(), in: 1...10)
         Stepper("Scale amount", value: $animationAmount.animation(
         .easeInOut(duration: 1)
         .repeatCount(3, autoreverses: true)
         ), in: 1...10)
         
         Spacer()
         
         Button("Tap Me"){
         animationAmount += 1
         }
         .padding(40)
         .background(.red)
         .foregroundStyle(.white)
         .clipShape(.circle)
         .scaleEffect(animationAmount)
         }*/
        
        /* Button("Tap Me"){     //did what asked for basic intro of animation part:- 1
         //animationAmount += 1
         }
         .padding(50)
         .background(.red)
         .foregroundStyle(.white)
         .clipShape(.circle)
         //.scaleEffect(animationAmount)
         //.blur(radius: (animationAmount - 1) * 3)
         .overlay(
         Circle()
         .stroke(.red)
         .scaleEffect(animationAmount)
         .opacity(2 - animationAmount)
         .animation(
         //.easeInOut(duration: 2)
         .easeOut(duration: 1)
         //.repeatForever(autoreverses: true),
         .repeatForever(autoreverses: false),
         value: animationAmount
         )
         )
         .onAppear{
         animationAmount = 2
         }
         //.animation(.linear, value: animationAmount)
         //.animation(.spring(duration: 1, bounce: 0.9), value: animationAmount)
         //.animation(.easeInOut(duration: 2), value: animationAmount)
         .animation(                   //customizing animations part:- 2
         .easeInOut(duration: 2)
         //.delay(1),
         //.repeatCount(3, autoreverses: true),
         //.repeatCount(2, autoreverses: true),
         .repeatForever(autoreverses: true),
         value: animationAmount)*/
    }
}

#Preview {
    ContentView()
}
