//
//  Home.swift
//  MovieDetails
//
//  Created by Arshdeep Singh on 2025-03-13.
//

import SwiftUI

struct Home: View {
    @State private var DeveloperInfo = false        // Made developer info variable to use it in sheet

    var body: some View {
        VStack {
            Text("Welcome to Movie Information")                //Main title of the App
                .font(.title)
                .fontWeight(.heavy)
                .multilineTextAlignment(.center)
                .padding()
            
            Image("home")                                         //custom image related to App
                .resizable()
                .scaledToFit()
                .cornerRadius(20)
                .frame(height: 250)
                .padding()
              
            Text("I used Arrival to fetch movie information from the iTunes API.")   //Requested line for homepage
                .font(.headline)
                .fontWeight(.bold)
                .multilineTextAlignment(.center)
                .padding()
             
            Button("Developer Info") {            //button to toggle developer info here
                DeveloperInfo.toggle()
            }
            .padding()
            .buttonStyle(.borderedProminent)
        }
        
        .sheet(isPresented: $DeveloperInfo) {
            MovieDetails.DeveloperInfo()         //sheet created to toggle developer info
        }
    }
}

#Preview {
    Home()
}
