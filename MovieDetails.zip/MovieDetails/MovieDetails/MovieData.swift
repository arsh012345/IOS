//
//  MovieData.swift
//  MovieDetails
//
//  Created by Arshdeep Singh on 2025-03-13.
//

import Foundation

struct Movie: Codable, Hashable, Identifiable {
    var id: Int { trackId } //made id as unique identifier
    
    let trackId: Int
    let trackName: String
    let releaseDate: String                     //variables defines with datatypes
    let primaryGenreName: String
    let trackPrice: Double?
    let currency: String
    let shortDescription: String?
    let longDescription: String?
}

struct MovieExtract: Codable {                  //movieExtract for codable use in decoding
    let resultCount: Int
    let results: [Movie]
}


extension Bundle {
    func decode(_ file: String) -> [Movie] {
        guard let url = self.url(forResource: file, withExtension: "json") else {         //error if file do not found
            fatalError("Can't find json file")
        }

        guard let data = try? Data(contentsOf: url) else {           //error if data loading problem occur in json file
            fatalError("Can't load data from json file")
        }

        let decoder = JSONDecoder()

        guard let movieDetails = try? decoder.decode(MovieExtract.self, from: data) else {      //error if cannot be decoded
            fatalError("Can't decode the JSON file")
        }

        return movieDetails.results
    }
}
