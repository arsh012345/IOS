//
//  ContentView.swift
//  MovieDetails
//
//  Created by Arshdeep Singh on 2025-03-12.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
                  Home()
                      .tabItem {
                          Label("Home", systemImage: "house.fill")
                      }

                  AllMovies()
                      .tabItem {
                          Label("Movies", systemImage: "film.fill")
                      }
              }
    }
}

#Preview {
    ContentView()
}
