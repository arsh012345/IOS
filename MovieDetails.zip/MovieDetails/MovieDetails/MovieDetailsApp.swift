//
//  MovieDetailsApp.swift
//  MovieDetails
//
//  Created by Arshdeep Singh on 2025-03-12.
//

import SwiftUI

@main
struct MovieDetailsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
