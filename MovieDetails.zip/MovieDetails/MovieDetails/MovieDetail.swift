//
//  MovieDetail.swift
//  MovieDetails
//
//  Created by Arshdeep Singh on 2025-03-13.
//

import SwiftUI

struct MovieDetail: View {
    let movie: Movie
    
    var body: some View {
        VStack(alignment: .leading, spacing: 10) {
            Text(movie.trackName)                    //track name or movie name at top as title
                .font(.title)
                .bold()

            Text(movie.longDescription ?? "No details available.")            //long description of movie
                .font(.body)

            if let price = movie.trackPrice {
                Text("Price: \(price, specifier: "%.2f") \(movie.currency)")    //price of movie decoded from json
                    .font(.headline)
                    .foregroundColor(.blue)
            }

            Text("Genre: \(movie.primaryGenreName)")             //genre name
                .font(.subheadline)

            Text("Released on: \(movie.releaseDate)")            //released date of movie
                .font(.subheadline)
                .foregroundColor(.gray)

            Spacer()
        }
        .padding()
        .navigationTitle(movie.trackName)
    }
}



