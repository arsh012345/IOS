//
//  AllMovies.swift
//  MovieDetails
//
//  Created by Arshdeep Singh on 2025-03-13.
//

import SwiftUI
struct AllMovies: View {
    let movies = Bundle.main.decode("myMovies") // Load movies using decode(_:)

    var body: some View {
        NavigationView {
            List(movies) { movie in
                NavigationLink(destination: MovieDetail(movie: movie)) {
                    HStack {
                        Image(systemName: "film.fill")
                            .foregroundColor(.blue)

                        VStack(alignment: .leading) {
                            Text(movie.trackName)
                                .font(.headline)

                            
                            Text(movie.shortDescription ?? "No description available.")
                                .font(.subheadline)
                                .foregroundColor(.gray)
                        }
                    }
                }
            }
            .navigationTitle("Movies (\(movies.count))")
        }
    }
}

