//
//  ContentView.swift
//  myfirstApp
//
//  Created by Arshdeep Singh on 2025-02-04.
//

import SwiftUI

struct ContentView: View {
    //MARK: - Properties
    var body: some View {
        VStack {
            Image(systemName: "airplane.circle.fill")
                .resizable(capInsets: EdgeInsets(top: 0.0, leading: 0.0, bottom: 0.0, trailing: 0.0))
                .frame(width: 0.0, height: 0.0)
                .imageScale(.large)
                .foregroundStyle(.stclairgreen)
            Text("Hello, Arsh!")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(Color.yellow)
                .multilineTextAlignment(.center)
            Text("-------------------")

                
            //TODO: - Add another view
        }
        .padding()
        //FIXME: - fix it
    }
}

#Preview {
    ContentView()
}
