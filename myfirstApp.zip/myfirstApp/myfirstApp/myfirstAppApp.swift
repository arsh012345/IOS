//
//  myfirstAppApp.swift
//  myfirstApp
//
//  Created by Arshdeep Singh on 2025-02-04.
//

import SwiftUI

@main
struct myfirstAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
