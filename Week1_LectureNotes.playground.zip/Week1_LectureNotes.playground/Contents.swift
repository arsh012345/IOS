import UIKit

/*:
This is a Swift Playground file. If you see a series of comments, turn this into rendered code by clicking on Editor > at the bottom of the Editor menu choose Show Rendered Markup
 */
/*:
 # Swift Introduction - Week 1
 ### Variables and named constants
* Programming languages use memory locations to store information.
 * Depending on the programming language, you may have to declare the type of data that the variable represents. (Weakly typed languages do not require a type – Strongly typed do)
 * Declaring a type and explicitly stating the type can be done - however with Swift there is a better way - it uses *type inference*.
 * There are ways to store values - one as a variable and one as a constant.
 * Declare variables using the keyword `var`
 * Constants represent values that will not change.  Constants are declared using the keyword `let`.
 * Names are written by convention using camelCase.  For example if you wanted to store a person’s name you would declare that the variable `firstName`
 * String variables can store any text data – single characters, collection of characters (including numeric) and an “empty string”
 * Numeric variables can store any type of  number – with or without decimal places
 * The syntax for declaring variables or constants where no value is being assigned looks like this:  `name:type` - where `name` is the variable or constant name (no difference between the two) followed by `:` followed by the type of information being stored.
 
*/
//declare a variable to hold a person's name - explicitly declaring the type
var personName: String = "Bob"

//declare a constant that will hold the maximum number of retrys - explicitly declaring the type
let maxRetry: Int = 5

//Assignment 1
//answer1:-
var peopleCapacity: Int = 50230
print(peopleCapacity)
 
//answer2:-
var waterBody: Double = 520.2
var waterDepth = "\(waterBody)m"
print(waterDepth)

//answer3:-
let testMarks: Int = 95
var testPercentage = "\(testMarks)%"
print(testPercentage)

//answer4:-
let lastCricketChamps = (country: "Australia", year: "2023")
print("The last CricketChamps of \(lastCricketChamps.0) happened in \(lastCricketChamps.1).")

//answer5:-
let driverAge = 15
print(driverAge >= 16 ? "You can drive, go ahead." : "You cannot drive sir!")

//answer6:-
func flightMessage(flightNumber num: String, timeDeparture time: String = "12:00"){
    print("Greeting traveler, your flight \(num) departs at \(time). Happy travels.")
}
flightMessage(flightNumber: "FB894", timeDeparture: "19:00")
flightMessage(flightNumber: "FB894")

//answer7:-
let dogWeight = 24.3

switch dogWeight{
case ..<24:
    print("Small dog")
case 24...59:
    print("Medium dog")
default:
    print("Large dog")
}



//Assignment-2

//Answer1:-
var awesome = "Star Wars: Episode V - The Empire Strikes Back"
let limit = awesome.startIndex..<awesome.index(awesome.startIndex, offsetBy: 11)
awesome.removeSubrange(limit)
print(awesome)

//Answer2:-
let sportsTeams = ["Red Wings", "Maple Leafs", "Blackhawks", "Bruins", "Canadiens","Rangers"]
let sortLetter = sportsTeams.filter {$0.hasPrefix("R")}
print(sortLetter)

//Answer3:-
func caldUsage(total: String, days: String) {
    
    guard let totalUsage = Double(total) else {
        print("Invalid total was entered.")
        return
    }
    guard let dayCont = Int(days), dayCont > 0 else {
        print("Invalid days entered. Enter positive numbers")
        return
    }
    
    let average = totalUsage / Double(dayCont)
    print("The average data usage of \(dayCont) days is about \(average) gb per day.")
}
//below four times is incorrect
caldUsage(total: "d", days: "5")
caldUsage(total: "50", days: "0")
caldUsage(total: "50", days: "a")
caldUsage(total: "50", days: "x")

//below one time is valid
caldUsage(total: "50", days: "5")

//Answer4:-
let topTelevisions: Set = ["Matlock", "Interview with the Vampire", "Summer Olympics", "Somebody Somewhere", "Bad Monkey", "Baby Reindeer", "Hacks", "Slow Horses", "Nobody Wants This", "Shogun"]

let showIwatched: Set = ["Interview with the Vampire","Baby Reindeer","Nobody Wants This","Hacks","Slow Horses","Shogun"]

let topListedones = ["Interview with the Vampire","Baby Reindeer","Nobody Wants This"]
let notRecommended = ["Hacks","Slow Horses","Shogun"]

print("Top hit shows of 2024 that I consider watching:-")
print(topListedones[0])
print(topListedones[1])
print(topListedones[2])

print("Shows of 2024 that I do not consider watching:-")
print(notRecommended[0])
print(notRecommended[1])
print(notRecommended[2])

//Assignment 3:
//Answer1:
class Home: CustomStringConvertible
{
    var address: String
    var numofBeds: Int

    var description: String {
        return "This home is at \(address), \(numofBeds) number of bedrooms."
    }

    init(address: String, numofBeds: Int) {
        self.address = address
        self.numofBeds = numofBeds
        print("Home has been built at \(address).")
    }

    deinit {
        print("Home at \(address) has been destroyed.")
    }
}

var homeAdd: Home? = Home(address: "3605 Dougall Ave.", numofBeds: 4)

if let home = homeAdd
{
    print(home)
}

homeAdd = nil

//Answer2:

class SavingsAcc{
    enum accTypes{
        case regular
        case highInterest
    }
    
    var accType: accTypes
    var accOwner: String
    var bal: Double = 0.0
    var loyaltyPoint: Int = 0
    
    init(accType: accTypes, accOwner: String) {
        self.accType = accType
        self.accOwner = accOwner
        print("Your new \(accType) savings account for \(accOwner) had been created.")
    }
    
    func addingMoney(amount: Double){
        if amount < 100{
            print("you do not have enough balance must deposit more than $100 at any time.")
            return
        }
        bal += amount
        
        if accType == .highInterest && amount >= 100{
            loyaltyPoint += 1
            print("Congratulations you have earned 1 loyality point: \(loyaltyPoint)")
        }
        
        print("$\(amount) has been deposited and new balance is $\(bal).")
    }
    
    func withdraw(amount: Double){
        if amount > bal{
            print("Insufficient funds. You cannot withdraw $\(amount).")
        }
        else{
            bal -= amount
            print("Withdraw $\(amount) and new balance is $\(bal).")
        }
    }
    
    func accDetails(){
        print("""
           Account owner is \(accOwner)
           Account Type is \(accType == .regular ? "Regular":"High Interest")
           Balance in account is: $\(bal)
           Loyality points: \(loyaltyPoint)
         """)
    }
}

// testing

let myAcc = SavingsAcc(accType: .highInterest, accOwner: "Arshdeep Singh")

myAcc.withdraw(amount: 10.00)
myAcc.addingMoney(amount: 90.00)
myAcc.accDetails()
myAcc.addingMoney(amount: 250.00)
myAcc.addingMoney(amount: 550.00)
myAcc.accDetails()

//Answer3:
enum preciousMetals{
    case gold(units: Double)
    case silver(units: Double)
    case platinum(units: Double)
    
    var unitsforValue: Double{
        switch self{
        case .gold:
            return 2638.70
        case .silver:
            return 29.15
        case .platinum:
            return 918.80
        }
    }
    
    var total: Double{
        switch self{
        case .gold(let units):
            return units * unitsforValue
        case .silver(let units):
            return units * unitsforValue
        case .platinum(let units):
            return units * unitsforValue
        }
    }
}

//array created to hold metals

let met: [preciousMetals] = [
    .gold(units: 1),
    .silver(units: 1),
    .platinum(units: 2)
]

var totalW = 0.0
for metal in met{
    totalW += metal.total
}

print("The total for precious metals will be $\(String(format: "%.2f", totalW)).")

//Answer4:
struct lapCom{
    var manufactured: String
    var smart: Bool
    var screen: Double
    var price: Double
    
    func details(){
        print("""
        Manufacturer: \(manufactured)
        Is it smart T.V. \(smart ? "Yes":"No")
        Screen Size: \(screen) inches
        """)
    }
    
    func namePrice(){
        print("\(manufactured) - $\(String(format: "%.2f", price))")
    }
}

let pc1 = lapCom(manufactured: "Apple", smart: true, screen: 32.3, price: 1398.99)
let pc2 = lapCom(manufactured: "Samsung", smart: false, screen: 28.5, price: 1234.99)

print("Details for Personal computer 1 is:")
pc1.details()
pc1.namePrice()
print("---------------------------------------")
print("Details for Personal computer 2 is:")
pc2.details()
pc2.namePrice()

//Assignment4

//Answer1:
struct Tenant {
    let name: String   //Created Tenant struct
}

struct Apartment {
    let address: String
    private var allTenants: [Tenant] = []
                                                //created struct that model Apartment with
    init(address: String) {                         //address and tenant property
        self.address = address
    }
   
mutating func addingTenants(_ tenant: Tenant) {
        allTenants.append(tenant)                 //created mutating function to add tenant in tenant array
    }
 
    subscript(key: String) -> String {
        switch key {
        case "address":
            return "The apartment is located at \(address)"
        case "tenants":
            if allTenants.isEmpty {
                return "There are no tenants here."
            } else {
                return "There are \(allTenants.count) tenants in this building."
            }
        default:
            return "Unknown value entered"
        }
    }
}

let tenant1 = Tenant(name: "Arsh")
let tenant2 = Tenant(name: "Shubh")           //created instance for all tenants
let tenant3 = Tenant(name: "Vicky")
let tenant4 = Tenant(name: "Harman")

var ouelleteApartment = Apartment(address: "1616 Ouellete Ave.")           //created apartment instance

ouelleteApartment.addingTenants(tenant1)
ouelleteApartment.addingTenants(tenant2)                  //adding all tenants to apartment
ouelleteApartment.addingTenants(tenant3)
ouelleteApartment.addingTenants(tenant4)

print(ouelleteApartment["address"])
print(ouelleteApartment["tenants"])            //using subscript to display result
print(ouelleteApartment["owner"])

//Answer2:

@propertyWrapper
struct Level
{
    private var values: Int                   //created property wrapper with level
    init(wrappedValue: Int)
    {
        self.values = min(max(wrappedValue, 0), 10)
    }
   
    var wrappedValue: Int {
        get { values }
        set { values = min(max(newValue, 0), 10) }
    }
}


class Stereo {                     //stereo model created
    let modelName: String
    @Level var volumeLevel: Int = 5          //volume level set to 5
   
    init(modelName: String) {
        self.modelName = modelName
    }
}

let myhomeStereo = Stereo(modelName: "JBL 8000")                     //instance of stereo created
print("Default volume of Stereo is: \(myhomeStereo.volumeLevel)")     //testing property wrapper of stereo
myhomeStereo.volumeLevel = -2
print("Changed the volume to -2: \(myhomeStereo.volumeLevel)")
myhomeStereo.volumeLevel = 14
print("Changed the volume to 14: \(myhomeStereo.volumeLevel)")

class Review {                                        //reveiw model created
    let descrip: String
    let group: reviewGroup
    @Level var rating: Int = 0                       //default rating set to 0
   
    init(description: String, category: reviewGroup) {
        self.descrip = description
        self.group = category
    }
}

enum reviewGroup {                       //enumeration used to create review related to school,home,work
    case school, home, work
}

let reviewByme = Review(description: "Great sound and bass..", category: .home)
print("Starting review rating: \(reviewByme.rating)")                  //testing property wrapper of review
reviewByme.rating = 111
print("Changed the rating to 111: \(reviewByme.rating)")
reviewByme.rating = -2
print("Changed the rating to -2: \(reviewByme.rating)")

//Answer3:

struct Movies: Decodable {
    let title: String
    let episodeTitle: String
    let network: String
    let primaryGenreName: String
    let purchasePrice: Double
    let description: String

    enum CodingKeys: String, CodingKey {
        case title
        case episodeTitle = "episode_title"
        case network
        case primaryGenreName
        case purchasePrice
        case description = "descr"
    }

    init(from decoding: Decoder) throws {
        let contain = try decoding.container(keyedBy: CodingKeys.self)

        title = (try? contain.decode(String.self, forKey: .title)) ?? "No Title availble"
        episodeTitle = (try? contain.decode(String.self, forKey: .episodeTitle)) ?? "No Episode availble"
        network = (try? contain.decode(String.self, forKey: .network)) ?? "Network not availble"
        primaryGenreName = (try? contain.decode(String.self, forKey: .primaryGenreName)) ?? "Genre no found"
        purchasePrice = (try? contain.decode(Double.self, forKey: .purchasePrice)) ?? 0.0
        description = (try? contain.decode(String.self, forKey: .description)) ?? "No description"
    }

    func detail() {
        print("""
        Title: \(title)
        Episode Title: \(episodeTitle)
        Network: \(network)
        Genre: \(primaryGenreName)
        Purchase Price: $\(String(format: "%.2f", purchasePrice))
        Description: \(description)
        """)
        print("***********************************************************************\n")
    }
}

//data provided
let stringData = """
[
    {
        "title": "Star Trek: The Original Series (Remastered)",
        "episode_title": "Where No Man Has Gone Before",
        "network": "CBS",
        "primaryGenreName": "Sci-Fi & Fantasy",
        "purchasePrice": 2.99,
        "descr": "While exploring the energy barrier at galaxy's edge that crippled an earlier ship, Kirk's long-time friend and crewmate Gary Mitchell begins mutating into a god-like entity disdainful of the mortals around him. Can the captain overcome his own feelings for his friend before the new entity grows too powerful to stop?  The Remastered edition features a more encompassing 3-D version  of the energy barrier and a view of the Delta-Vega lithium station at dawn. Also, the digital U.S.S. Enterprise model is true to the unique details seen in the original miniature at this stage, the series' second pilot episode."
    },
    {
        "title": "Star Trek: Discovery",
        "episode_title": "The Vulcan Hello",
        "network": "Paramount",
        "primaryGenreName": "Drama",
        "purchasePrice": 3.49,
        "descr": "Series premiere. While patrolling Federation space,  the U.S.S. Shenzhou encounters an object of unknown origin, putting First Officer Michael Burnham (Sonequa Martin-Green) to her greatest test yet. Starring Sonequa Martin-Green, Michelle Yeoh, Doug Jones."
    },
    {
        "title": "Star Trek: Enterprise",
        "episode_title": "Broken Bow, Pt. 1",
        "primaryGenreName": "Sci-Fi & Fantasy",
        "purchasePrice": 1.99,
        "descr": "Jonathan Archer quickly assembles a crew to return the Klingon to his people using Earth's first Warp 5 starship, Enterprise. When the ship is attacked, the Klingon is abducted, and Archer's crew is drawn into an intrigue that spans both space and time."
    }
]
"""

let data = Data(stringData.utf8)

do
{
    let movies = try JSONDecoder().decode([Movies].self, from: data)
    for movie in movies {
        movie.detail()
    }
}
catch
{
    print("Error: \(error.localizedDescription)")
}

/*:
### Type Inference
With Swift, we will make use of type inference when assigning a value.  Swift is very good at detecting what type of information you are working with, based on the value that is being assigned.
 * Explicitly describing types is not always required in Swift - usually only required when you are not providing a value
 * The Swift compiler is able to infer the data type
 * Type inference allows for the removal of the redundancy of explicitly declaring a type
 * When assigning a value to a variable, Swift can infer what the appropriate data type is
 */
//declare a variable to hold a person's name using inference


//declare a constant to hold the maximum number of retrys using inference
let inferredRetry = 6

/*:
 When combining literal values, the compiler will infer what types based on the context
 */


/*:
 Reveal the type by choosing Option + clicking on it
 */
/*:
 But why a double and not a float.  Swift infers a Double - and it suggests that for most cases a Double is the preferred data type.  If you require a Float, then you would have to explicitly declare this.  See below for more information on types.
 */
/*:
 ### Type Conversion
 The compiler will enforce type safety. It will not allow you to add two different types together.  To see the results, remove the // from in front of `sum = integer + double` and run the playground.  It will give you and error.  You can't fool it - even if you tried the same thing with the `sum = integer + anotherDouble`.
 */
let firstInt = 3
let seconInt = 5

let result = firstInt + seconInt



//sumOfNumbers = integer + double

/*:
 ## Types
 ### Integers
 * Integers are whole numbers with no fractional component
 * Integers are either signed (positive, negative or zero) or unsigned (positive or zero)
 * Swift provides signed and unsigned integers in 8, 16, 32 and 64 bit forms
 In most cases you don’t need to pick a specific size of integer
 * Swift provides an integer type Int which is the size of the current platform’s native word size
 * On a 32bit platform it is an `Int32`
 * On a 64bit platform it is an `Int64`
 **NOTE** – unless you require a specific size integer, use Int for values in your code
 
 **NOTE**: it is recommended that you only use an UInt when you specifically need an unsigned integer type.
 */
/*:
 *"Use UInt only when you specifically need an unsigned integer type with the same size as the platform’s native word size. If this isn’t the case, Int is preferred, even when the values to be stored are known to be nonnegative. A consistent use of Int for integer values aids code interoperability, avoids the need to convert between different number types, and matches integer type inference, as described in [Type Safety and Type Inference](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/#Type-Safety-and-Type-Inference)."*
 */
/*:
 ### Floating Point Numbers
 Floating point numbers are used to represent numbers that contain a decimal (numbers with a fractional component)
 * Represent a much wider range of values than integer types and can store numbers that are smaller than an `Int`
 
 There are two types
 * `Double` – represents a 64-bit number – has a precision of at least 15 decimal digits
 * `Float` – represents a 32-bit number – store as little as 6 decimal digits
 
 A double has twice the level of precision as a float – hence the name double.
 
 **NOTE:**  where either type would be appropriate, `Double` is preferred
 */
/*:
 Large numbers can be difficult to read
 Placing a comma for readability is not allowed
 */
let largeNum = 100_000_000_000_000

/*:
 Use underscores for clarity – does not affect the value of the literal, but makes it easier to read
 */
/*:
 ###  Numeric Operations
 Numeric calculations use arithmetic operators:
 * `+`  for addition
 * `-` for subtraction
 * `*` for multiplication
 * `/` for division
 * `%` for modulus
 
 In most languages operations are carried out in this order:
 * Exponential operations performed before any basic arithmetic operation
 * Multiplication and division
 * Addition and subtraction
 * **BEDMAS**
 */
/*:
 ### Increasing and Decreasing Numbers
 For example – you want to increase a numeric variable by 1
 */
var starterValue = 1
starterValue = starterValue + 1




/*:
 We can use a shorthand version where we combine the `+` and `=` to `+=`
 */
starterValue += 1

//myNumber *= 1


/*:
 Or to decrease the value
 */
starterValue -= 1



/*:
 **There is no ++ operator**
 */
/*:
 ### Printing Results to the Console
 The print function allows us to display formatted text in the console.
 
 ![printDetails](printFunctionDetails.png)
 */
/*:
 **Do not** provide a print statement with multiple variables, separated by columns.  **This is important to remember and will cost marks on assignments**
 */
var name = "Obi-Wan Kenobi"
print(name)

/*:
 ### Program Comments
 * For single line comments use //
 * For multi-line coments use \/ * * \/
                                
 */
/*:
 #### Unicode
 Unicode characters can be represented in Swift using the specified Unicode value.  For example, take a look at the following chart:
 
 ![Dingbats chart from Unicode](Dingbats.png)
 If we wanted to add that arrow character we would use `\u{n}` in Swift where n is the hexadecimal code
 */

/*:
 Swift also allows you to use emojis and symbols as variable names (to access emojis, select Edit at the top and then Emoji & Symbols)
 */
let 🐶 = "Sasha"
print(🐶)

print("\u{2744}")
/*:
 Fun to do - but **don't do it**!  This makes you code terrible to support and work with!
 */

/*:
 ### Concatenation
 Concatenation uses the addition operator (+) to join the two strings together.
 It literally joins two strings together - it will **not** add any space between the two literals being joined.
 Strings can be added together using the addition operator (+)
 */
let firstString = "Oh no"
let secondString = " on thw screen "
print(firstString + secondString)

/*:
 You can also append a string value to and *existing* string variable with the addition assignment operator (+=)
 */

/*:
 ### String Interpolation
 * Strings can also be built using interpolation and it is a much cleaner method for building strings
 * Interpolation places the variable in a string as a placeholder – this tells Swift to replace the placeholder with the actual value
 * It is more readable than concatenation – you see exactly what result you will get before compiling
    * With concatenation it is often difficult to see the output before running and errors are noticed once the output is displayed
 * Format for string interpolation is `\(n)` where `n` is the variable or constant name
 ### IMPORTANT:
 **String interpolation is the preferred method for formatting and joining strings - including in the print statement**
 */

print("Help me \(name), you are my only hope.")

/*:
 ### Multi-line Strings
 * If you need strings to span several lines, use a multiline string literal
 * The characters are surrounded by three double quotes
 * All code will line up with the level of indentation **PRIOR** to  the closing `“””`
 */
var openingCrawl = """
    It is a period of civil war.
    Rebel spaceships, striking
    from a hidden base, have won
    their first victory against
    the evil Galactic Empire.
    
    During the battle, Rebel
    spies managed to steal secret
    plans to the Empire's
    ultimate weapon, the DEATH
    STAR, an armored space
    station with enough power to
    destroy an entire planet.
    
    Pursued by the Empire's
    sinister agents, Princess
    Leia races home aboard her
    starship, custodian of the
    stolen plans that can save
    her people and restore
    freedom to the galaxy.....
    """
print(openingCrawl)

/*:
 Indentation determines how the information will be displayed.
 */

/*:
 ### Tuples
 * Tuples group multiple values into a single, compound value
 * The grouped values can be of **any type** – they can even be **different types**
 * This allows for creation of simple groups of related values and allows for the *return* of multiple values where other languages only allow a single value
 * The syntax for a basic tuple is
 `(someValue, someValue, ...)`
 */
/*:
 Tuples can contain the same type of information
 */
var flightDetails = ("dda", "add")

/*:
 Or the tuples can be of different types
 */
var flightDetail2s = ("arg","agg",133)


/*:
 ### Decomposing Tuples
 * Decomposing a tuple means extracting the values into separate constants or variables
 * Values are stored in an ordered manner – the first value can be accessed by its position
 * Tuples use zero indexing – the first position is at index 0 not 1
 * Decomposing or extracting the values from a tuple can be achieved in several ways
 * Explicitly assign to variables or constants
 */
let(departure, arrival) = flightDetails
print(departure)
/*:
 Or tuples can be accessed using their index value
 */
print("\(flightDetails.0) \(flightDetails.1)")
flightDetails.1


/*:
 However using an index is not intuitive - 0 has no meaning it simply means the first item.
 Instead assign names to the individual elements inside of the tuple
 */
var completeflightDetails = (departure: "wfa", arrival: "ad", flightNumber: 1233)
completeflightDetails.departure; completeflightDetails.arrival

let (_,_,flight) = completeflightDetails
flight
/*:
 You may need to access a specific element in a tuple, and ignore the rest
 * The underscore is often used to meet the requirements of the compiler, but not waste using a memory location for a value that you will never require
 */


/*:
* Tuples are especially useful as return types for functions
* Can return more than just a single value of a single type
* Not meant for the creation of complex data structures that need to persist beyond a temporary scope
 */
/*:
 # Control Structures
 ### If/Else Statements
 * Here is the syntax for a basic conditional statement
 **NOTE:** - there are no ( ) around the condition
 */
var currentSpeed = 80
if currentSpeed >= 80{
    print("slow down!")
}


/*:
 The if/else syntax
 */


/*:
 ### Comparison Operators
 ![Comparison Operators](comparisonOperators.png)
 */
/*:
 ### Logical Operators
 ![Logical Operators](logicalOperators.png)
 */
/*:
 ### Ternary Operator
 Ternary conditional operator is a special operator with three parts
 
 Syntax follows :
 
 `Question ? Answer1 :  Answer 2`
 
 If the question is true, then it returns whatever is represented by answer 1 and otherwise it returns whatever is represented by answer 2.
 This is shorthand code for
 
                 if question {
                    answer1
                 } else {
                    answer2
                 }

 
 If the lines of code start to wrap it is best to not use the ternary operator
 
 **NOTE** – the ternary operator can be hard to read.  Avoid combining multiple instances of the ternary operator
 */
print(currentSpeed >= 80 ? "Slow Down" : "carry on!")


/*:
 ### For-in Loops
 A for-in loop is used to iterate over a sequence
 */
for i in 1...3{
    print("Bettlejuice!")
}

/*:
 The constant `i` represents the current value of the iterator
 This only exists inside the body of the loop - between the {}
 */
/*:
If you do not need the value it can be ignored using an underscore (_)
 */


/*:
 ### Type Inference in Loops
 `For` loops utilize type inference to identify the value type of the variable
 * This reduces the possibility of error
 */
/*:
 ### While loops
 */



/*:
 ### Repeat-while loops
 * Similar to `do-while` loops in other languages
 */


/*:
 ### Switch
 * Every switch statement **MUST** be exhaustive – every possible case must be considered and must be a case
 * If it is not possible to provide every possible option, then a default value (indicated with the keyword `default`) is provided
 * Breaks are **not required** - the code does not automatically fallthrough.  They are only required if there is an absence of code in your case.
 */




/*:
 The body of each case **MUST** contain at least one executable statement

 */
/*:
 Multiple matches for a single case can be separated by commas
 */



/*:
 ### Ranges
 Switch statement can make use of range operators
 
 Closed range operator (…) – an inclusive list including the value to the left and the value to the right (note the three dots)
 
 `case 1...5: //is the value 1,2,3,4 or 5`
 
 Half-open range operator (..<) – this is a list of values starting with the value to the left and ending before the value on the right (does NOT include the right hand value)
 
 `case 1..<5: //is the value 1,2,3 or 4`
 
 */
/*:
 # Functions
 ### Basic Functions
 A function is defined with the keyword `func`
 
 Parentheses wrap arguments – which are optional
 
 An opening **{** defines the beginning of the function and a **}** denotes the close or end of the function
 
 **NOTE** – in Swift the { and } are required for all functions, even if the function code is a single line
 */
/*:
 ### Function Parameters
 * Parameters provide input to the functions
 * An argument is the *value* that a caller gives to the function’s parameters
 * Arguments that are provided to the function must match the type that is defined.
 * A function can take as many parameters as required to perform its task.  The parameters are all defined with a type and separated with a ,
 */

 

/*:
 ### Parameter Names
 Sometimes it is useful to have all of a function’s parameter named
 * This makes your functions more readable
 * The external parameter names are used when *calling* the function
 * The internal parameter names are used *inside* the function
 */

//pagingOfficer(officerName officer: <#T##String#>, toLocation location: <#T##String#>)


/*:
 As you can see in the above code - calling the function you use the external names
 
 ![function with external names](externalNames.png)
 
 And use internal names when working with the code *in* the function
 
 ![function use with internal names](internalNames.png)
 */
/*:
 ### Default Parameter Values
 * Default values should be put at the end of the parameter list
 * Default values are written using the assignment operator
 * Call the function and pass no values to use the default value
 * Call the function and pass a value to override the default value
 */



/*:
 You can now call this function two different ways
 
  
 */
/*:
 ### Omitting External Parameter Names
 If you do not want to use an external parameter name for any parameter you can simply use an _ in its place.  This is **NOT** recommended as it makes your function more difficult to understand.  Use with appropriate function naming - for example:
 */
/*:
 ### Returning from a function
 All functions return a value
 * If no return type is defined, the function returns a value of type Void an empty tuple with zero elements – `()`
 To specify a return value you include the return arrow (`->`) and a return type
 * Multiple lines of code require the use of the keyword `return`.  If the body of the function is only made of a single line, the `return` keyward may be omitted.
 */

//func addTwoNumbers(firstNumber: Int, secondNumber: Int) -> (Int, Int, Int) {
//     (firstNumber, secondNumber, firstNumber + secondNumber)
//}
//
//func addTwoNumbers(firstNumber: Int, secondNumber: Int) ->  Int{
//     firstNumber + secondNumber
//}
//
//let sumVal = addTwoNumbers(firstNumber: 1, secondNumber: 1)
//sumVal.0

/*:
 Return values can be ignored – but a function set to return a value must always return the value.
 * Attempting to allow control to fall out the bottom of the function without returning a value will result in a compile-time error
 */
/*:
 ### Nested Functions and Scope
 Functions can be defined within the bodies of other functions (nested functions
 * Nested functions are hidden from code outside the function it is nested in
 * An enclosing function can also return one of its nested functions to allow the nested function to be used in another scope
 * Useful when you want to hide or isolate parts of your code
 */
/*:
 ### Multiple Returns
 Functions return a **single** value
 
 Functions that return a *tuple* type as the return type are able to return *multiple values* as a single compound return value
 */
/*:
 ### Function Types
 Every function has a specific function type – made up of the parameter types and the return type of the function
 */
//use option click to see the type of function




/*:
 The type of this function is `(String) -> Int`
 
 ![Example of return type](returnTypes.png)
 */
/*:
 This is an example of no parameters or return value.
 */


/*:
 ![Return Void Example](returnVoid.png)
 This is a return type of `() -> Void`
 */
/*:
 Function types can be used exactly like any other *type*.
 */
/*:
 ### Function Types as Parameters
 Function types can be passed as parameters for another function
 */




/*:
 **NOTE** the absence of the () - when you use the () this means to call it
 */
