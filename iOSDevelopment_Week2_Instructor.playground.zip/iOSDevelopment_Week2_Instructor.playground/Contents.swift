import UIKit
/*:
  # Optionals
  ### Optional Definition
  Swift requires variables and constants to have a data type
  
  It also requires that they be initialized with some value in order to use them
  
  Optionals in Swift are meant to accommodate instances where there is no value – where the value is **nil**
  
  Optionals are a special feature in Swift:
 * It represents two possibilities
     * There is a value – you can then unwrap the optional and use it
     * There is no value – it is nil
  
  Remember in Swift that variables and constants must have an initialized value
  
  *Optionals make the language safer*
 * If an object is **NOT** declared as an optional then you are guaranteeing that there is a value to the compiler
  
  Optionals are types and can contain a value of any type
  
  They can only hold one value
  */
var firstValue: Int = 5
var secondValue: Int? = 6
print(secondValue)
//var result = firstValue + secondValue

/*:
  If the compiler senses it might fail, it infers the optional type rather than the full type
  
  The `?` indicates an optional type.
  * Remember - it can contain a value **of the type** or no value at all.  It cannot contain anything else.
  
          let possibleNumber = "dog"
          let convertedNumber = Int(possibleNumber)
  
  This cannot work - you can not convert a string of characters into a number.  So this will set `convertedNumber` to `nil`, rather than crash when the code runs.
  */
/*:
  ### nil
  You can set an optional variable to a valueless state using the value `nil`
  
  It can not be used with any non-optional variable or constant
  
  If you define an optional without providing a default value *nil* is set
  */
/*:
  ### Optionals with conditions
  To check the value of an optional value you can use a conditional statement
  */

 //optional with conditions
var whatIsThis: String? = "yes"

if whatIsThis == nil{
    print("There is nothing here")
} else {
    print("\(whatIsThis), there is something here")
}

/*:
  ### Unwrapping Optionals
  Think of optionals being values that are stored in a box
  
  You can’t see the value since it is ‘wrapped’ in the box
  
  In order to use the value you have to unwrap it
  
  But what if there is nothing in the box?  You won’t know until you have unwrapped the value
  
  Note that the value in the previous example was an `Optional(2)`

  Explicitly unwrapping involves telling the compiler to go ahead and use a value
  
  You make use of the (!) character to indicate to the compiler to go ahead and process the optional – that you *guarantee* that there is a value & **it is safe**
  */
/*:
  ### Explicitly Unwrapped Optional
  **DANGER**
  
  **Do not use ! to guarantee that there is a value, if there is *even the smallest chance that the value might be nil***
  
  There are specific use cases where this will be appropriate. For now, assume that adding a ! to clear a message or deal with what might be nothing is a bad thing to do.
  */
/*:
  ### Optional Binding
  Optional binding is a **pattern** that allows you to *safely and concisely* detect if an optional contains a value
  
  **This is the method for dealing with optional values.**
  
  This attempts to assign the variable to a *temporary* constant.  If the assignment works - there is avalue there and you may now use that value safely. If the assignment fails, you have some code to handle this situation safely.
  
  */
let optionalValue = "12"
let secondOptionalValue = "13"
if let firstNumber = Int(optionalValue){
    print("\(firstNumber)")
}
if let secondNumber = Int(secondOptionalValue){
    print("\(secondNumber)")
}




/*:
  Change the firstNumber to "one" to see how the code executes without crashing
  */
/*:
  ### Unwrapping multiple optionals
  Multiple optionals can be tested by separating them by a comma
  */
if let first = Int(optionalValue), let second = Int(secondOptionalValue){
    print("The sum of \(first) + \(second) = \(first + second)")
}



/*:
  All values must equate to true for the if block to execute.
  */
 //swap first to "one" to see how it executes without crashing
/*:
  ### Nil Coalescing Operator
  Useful when you either want to add a value to a variable/constant *IF* it exists or use a default value if it is nil
  */
var optionalWord: String?
//optionalWord = "Hello"

print(optionalWord ?? "No word to print")


/*:
  In the above it will either set the string to the text or to `There is no value`
  */

/*:
  ### Early Exit from function
  A `guard` statement is used to transfer program control out of a scope if one or more conditions aren't met
  It has the following form
  
                  guard <#condition#> else {
                  <#statements#>
                  }
          
  The result of any condition in the statement must be of type `Bool` or an optional binding condition

  A guard statement **always** has an else clause that is executed IF the condition is not true
  
  If the condition is met
 * Code execution continues without executing the code in the else
 * Any variables and or constants assigned values using optional binding as part of the condition are available until the end of the closing brace of the function where the guard statement is embedded

  If the condition is NOT met
 * The code inside the else branch is executed
  */
func printEvenNumbersUnder100(number: Int?){
    guard let unwrappedValue = number else {
        print("Nothing here")
        return
    }
    
    guard unwrappedValue < 100 else {
        print("Not under 100")
        return
    }
    
    if unwrappedValue % 2 == 0{
        print(unwrappedValue)
    } else {
        print("Not an even number")
    }
}

printEvenNumbersUnder100(number: nil)
printEvenNumbersUnder100(number: 100)
printEvenNumbersUnder100(number: 3)
printEvenNumbersUnder100(number: 22)


/*:
 ### Closures
 * *Closures are self-contained blocks of functionality that can be passed around and used in your code*
 * Can capture and store *references* to any constants and variables from the context in which they are defined
 * This is known as **closing over the constants/variables**
 * Functions are special cases of closures

          Closure Syntax:
                  {(parameter: ParameterType, parameterTwo: ParameterType,...)-> Return Type in
  
                    //the code to be executed goes here
  
                    return someValue //this value matches the Return Type
                  }
  
  The keyword `in` separates the closure's definition for the code to execute
  *   Write the code to execute and end with the closing curly brace
  */
/*:
  They contain optimizations that encourage brief, clutter-free syntax
  They include:
 * Inferring parameter and return value types from context
 * Implicit returns from single-expression closures
 * Shorthand argument names
 * Trailing closure syntax

  */
/*:
  ## Simple Closures
  */
 let simpleClosure = {
     ()->Void in
     print("I am Batman")
 }

 simpleClosure()

/*:
  In the above example we are creating a simple closure and calling it.  This closure takes no additional information - no parameters and arguments are involved (hence the () -> Void)
  */
/*:
  If we wanted to provide some data for processing, we could make use of parameters
  */
 let exampleClosure = {
     (name: String) -> Void in
     print("I am \(name)")
 }

 exampleClosure("Batman")


/*:
  If we want to return some information we would define the return type on the closure
  */
 let returnClosure = {
     (name: String) -> String in
     return "I am \(name)"
 }

 returnClosure("Spider-man")


/*:
  ## Sorted by
  Swift provides a method called `sorted(by: )` that allows you to specify how to sort an array
  */
 let names = ["Mal", "Zoe", "Simon", "River", "Jayne", "Kaylee"]

 //names.sorted(by: <#T##(String, String) throws -> Bool#>)

/*:
 * It takes one argument – it takes a closure **(String,String) -> Bool** that describes how the sorting should be done
 * This closure takes two arguments whose types *must* match the type of the elements in the array and returns a Bool
 * The arguments are compared to produce the return value – which represents whether the instance of the first argument should be sorted before the instance in the second argument
     * Sorts the array in an ascending order
  */
func backwardSort(value1: String, value2: String) -> Bool{
    return value1 > value2
}



/*:
  In the above we created a function that takes two `Strings` and *returns* a `Boolean`
  
  The type of this function is `(String, String) -> Bool`
  */
print(names)
//var reversed = names.sorted(by: <#T##(String, String) throws -> Bool#>)
var reversed = names.sorted(by: backwardSort)
print(reversed)




reversed = names.sorted(by: {(string1: String, string2: String) in
    return string1 < string2
})
print(reversed)

/*:
  ## Inferring type From Context
  Because the sorting closure is passed as an argument to a method, Swift is able to infer the type of its parameters *AND* the type of the value it returns
  
  Because the sorted method is being called on an array of `Strings` (names) and the type of `Bool` can be inferred based on the return (a `String` being compared to see if it is greater than another `String`) - they can now be inferred and they can be removed

  */

//reversed is an array of strings

reversed = names.sorted(by: {(string1, string2) in
    return string1 > string2
})
print(reversed)


/*:
  ## Implicit Returns from Single-Expression Closures
  Single-expression closures can implicitly return the result of their single expression by omitting the `return` keyword
  */
reversed = names.sorted(by: {(string1, string2) in string1 < string2})
print(reversed)



/*:
  Swift provides shorthand argument names to inline closures
  
  Arguments are preceded by the $ character and they increase for each parameter
  * First parameter is 0 - $0
  * Second parameter is 1 - $1
  */
reversed = names.sorted(by: {$0 > $1 })
print(reversed)


/*:
  ## Operator Methods
  Swift’s `String` type defines a string-specific implementation of the greater-than operator (>)

  Defines it as a method that has two parameters of type `String` and returns a value of type `Bool`
 *  This matches the method type needed by the sorted(by: ) method
 *  Can shorten to match this
  */
reversed = names.sorted(by: <)
print(reversed)


/*:
  ## Trailing Closures
  If the **final argument** is a closure, and the closure expression is long, you can use a trailing closure instead
  
  A trailing closure is written *after* the function call’s parentheses
  
  It is still an argument to the function
  */
 //Trailing Closures

func someFunction(name: String, closureParameter: () -> Void){
    print("\(name)")
}

someFunction(name: "bob", closureParameter: {
    //closure code here
})


someFunction(name: "bob") {
    //closure code here
}

/*:
  This syntax is used repeatedly - get used to seeing this
  */
 /*:
  ## Functions as Return Types
  Remember – every function has a function type
  
  This defines the function’s or closures parameters and return types
  
  For example –
 * A function that takes a `String` argument and returns an `Int`
 * This has the function type `(String) -> Int`
  
  For example: Let's calculate mean, median and mode
  */
/*:
  The mean is the average of a set of numbers
  */
func mean(numbers: [Int]) -> Double {
    var sum = 0
    for number in numbers {
        sum += number
    }
    
    let mean = Double(sum) / Double(numbers.count)
    return mean
}


/*:

  The median is the midpoint of a distribution of numbers

  Put the numbers in order and find the mid-point
  */
func median(numbers: [Int]) -> Double{
    let sortedNumbers = numbers.sorted(by: {$0 < $1})
    
    let midIndex = numbers.count/2
    
    let median = Double(sortedNumbers[midIndex])
    
    return median
}



/*:
  Mode is the value that occurs the most
  
  If no number is repeated there is no mode
  */
func mode(numbers: [Int]) -> Double{
    var occurrences: [Int: Int] = [:]
    
    for number in numbers {
        if let value = occurrences[number]{
            occurrences[number] = value + 1
        } else {
            occurrences[number] = 1
        }
    }
    
    var highPair : (key: Int, value: Int) = (0,0)
    
    for (key,value) in occurrences{
        highPair = (value > highPair.value) ? (key,value) : highPair
    }
    
    return Double(highPair.key)
}




/*:
  Return a tuple that represents the mean, median and mode
  */
func performMathematicalCalculations(values: [Int], calculation:([Int])-> Double) -> Double{
    calculation(values)
}

let values = [1,2,3,4,5,1]

performMathematicalCalculations(values: values, calculation: mean)
performMathematicalCalculations(values: values, calculation: median)
performMathematicalCalculations(values: values, calculation: mode)


/*:
 ## Collections
 ### Arrays
 
 Arrays are used to store **multiple values** of the **same type**
 
 Arrays are an **ordered** list of non-unique elements
 
 An array is **not a unique list of values**
 
 ## Array Syntax
 There are multiple ways to declare arrays
 
 Angle brackets tell what instances an array will hold (this is generic syntax which we will see about later in the course)
 */
//var newArray: Array<String>

/*:
 Shorthand syntax is easier to read
 */
var newArray: [String]

/*:
 You can initialize an array with values and make use of type inference
 */
var studentNames = ["Harry", "Ron", "Hermione"]


/*:
 Or to create an empty array - here you will be required to provide a type
 */
var emptyArray = [Double]()

/*:
 ## Populating an Array
 You can add items to your array at creation - using literal values
 */
var vehicles = ["Honda", "Toyota", "Nissan"]


/*:
 After creating an array you can add items using the append method.
 */
vehicles.append("Nissan")

/*:
 You can add another array to an array - merging them together
 */
var domestic = ["Ford", "GM", "Dodge"]
vehicles += domestic

print(vehicles)



/*:
 Arrays are ordered lists - if you want to place an item in a specific position or edit a specific item, you can use the subscript to do it (as long as that subscript position exists)
 Arrays are zero-indexed - the first position is position 0
 */
print(vehicles[2])

/*:
 ## Inserting Items Into An Array
 To insert an array item at a specifc spot, use the insert method and provide a specific index location
 */
vehicles.insert("Volvo", at: 2)
print(vehicles)


/*:
 ## Removing Array Elements
 Items can be removed by using the `remove(at:)` method
 */
vehicles.remove(at: 2)
print(vehicles)
/*:
 If the item is at the  end of the array, you can remove the item using the `popLast()` method
 */
//let last = vehicles.popLast()

/*:
 **NOTE**: that this is an optional value.  There may not be a last item (empty array)
 */
if let last = vehicles.popLast(){
    print("\(last) has been removed")
    print(vehicles)
} else {
    print("No vehicles to remove")
}

/*:
 ## Accessing Array Elements
 Items can be selected using the subscript
 */
vehicles[1]

/*:
 Using range operators you can also access the contents of an array
 */
print(vehicles[0..<2])

/*:
 Range operators can be used to replace items in an array
 */
vehicles[0..<2] = ["Kia", "Hyundai"]
print(vehicles)


/*:
 And also to remove items
 */
vehicles[0..<2] = []
print(vehicles)



/*:
 ## Displaying Array Contents
 Need to know what an array contains, use a `for loop` to iterate over the contents of an array
 */
for vehicle in vehicles {
    print(vehicle)
}


/*:
 ## Array Properties
 The `count` property is used to determine the total number of elements in an array
 */
vehicles.count

/*:
 The `isEmpty` property returns a boolean to tell you if the array is empty or not
 */
print(vehicles.isEmpty)

/*:
 You can determine the first item in the array using `first` property.  The `last` property returns the last item in the array.
 */
print(vehicles.first)
print(vehicles.last)


/*:
 **NOTE:** the types of each of these - optionals since there may not be a value there
 */
/*:
 You can also get the first and last index positions
 */

/*:
 ## Array Contents And Indices
 If you want to get the index AND the value of the item in the array, you will need to use the `enumerated()` method
 */
for (index,brand) in vehicles.enumerated(){
    print("\(brand) was found at index #\(index)")
}

/*:
 If you want to know if some value is contained in the array, use the `contains()` method - it returns true or false
 */
if vehicles.contains("Nissan"){
    print("Nissan is in the list of car brands")
} else {
    print("Nissan is not int he list")
}



/*:
 You can see if two arrays contain the same values (test for equality) using the == operator
 */
var cars = vehicles
cars.append("VW")
if cars == vehicles{
    print("They are the same")
} else {
    print("They are not the same")
}

/*:
 ## Dictionaries
 A dictionary is a collection type that stores information in **key** and **value** pairs
 * There is no defining order to items in the dictionary – use to lookup values based on the identifier (key)
 
 To create a mutable dictionary use the following syntax
 
 `var dictionaryName < key type, value type>`
 
 The key value has to be hashable
 
 Keys must be unique
 
 String, Float, Double, Int, and Bool are all hashable (*they conform to the Hashable protocol*) meaning they are classified as unique types
 
 */
/*:
 ## Create Dictionaries
 To create an empty dictionary (where the key is an integer value and the value is a string)
 */
var sample = [Int: String]()
//or
var longDictionarySample: Dictionary<Int, String> = [:]

//or assign
//var pantry = ["Beans": 3, "Corn": 1, "Spam" : 13]
var pantry = [
    "Beans": 3,
    "Corn": 1,
    "Spam" : 13
]
print(pantry)
/*:
 **NOTE:** the items will not appear in the order that you assigned them - dictionaries are unordered!
 */


/*:
 ## Populate a Dictionary
 Populating a dictionary - values can be added to an empty dictionary
 */
var inventory = [
    "Plates" : 12,
    "Forks" : 3,
    "Spoons" : 2
]

print(inventory)

inventory["Cups"] = 3

print(inventory)



/*:
 Items can also be added to the dictionary using the key and providing a value
 */
inventory["Cups"] = 3
print(inventory)

/*:
 # WARNING:
 When adding items to the dictionary, be careful - if the item's key already exists, the item won't be added, but the existing key's value will be changed
 */
inventory["Cups"] = 14
print(inventory)


/*:
 ## Accessing Dictionary Elements
 To access an item in the dictionary - use its key using subscript syntax - **NOTE**, the key may not exist - so use optional binding to safely unwrap the value associated with the specified key
 */
if let amountOfCups = inventory["Cups"]{
    print("We have \(amountOfCups)")
} else {
    print("I think we are out of cups.")
}

/*:
 ## Modifying Dictionary Elements
 Values can also be modified using the subscript syntax
 */
//oops I broke a cup
inventory["Cups"] = 13

/*:
 Values can also be updated using the `updateValue(_: forKey:)` method.
 
 The difference between the two methods is that `updateValue` returns what value was updated
 */
let beforeAdditionTotals = inventory.updateValue(4, forKey: "Spoons")
//let beforeAdditionTotals = inventory.updateValue(4, forKey: "Knives")
print(beforeAdditionTotals)

/*:
 ## Removing Items From A Dictionary
 Items can be removed from a dictionary using the `removeValueForKey()` method
 */
let removedItem = inventory.removeValue(forKey: "Cups")
print(inventory)
print(removedItem)

/*:
 Specific keys can be removed by setting their values to nil
 */
/*:
 ## Dictionary Contents
 You can view the contents of a dictionary by iterating over the contents and using a tuple to decompose the dictionary items
 */
for (key,value) in inventory{
    print("We have \(value) \(key)(s)")
}

/*:
 If we only want the `keys` use the keys property
 */
for inventoryType in inventory.keys{
    print(inventoryType)
}

/*:
 Or the `values` property for the just the values
 */
for value in inventory.values{
    print(value)
}


/*:
 ## Dictionary Properties
 Like arrays we can see whether a dictionary contains anything using the `isEmpty` property.  And also how many items it contains with the `count` property
 */
print(inventory.isEmpty)

/*:
 ## Sets
 A set stores **distinct** values of the same type and has *no defined ordering*
 
 You can use a set instead of an array when the order of items is not important but you need an item to **only appear once**
 
 The set types must be hashable
 
 All of swifts basic types are hashable by default so they can be used for sets

 
 */
/*:
 ## Creating Sets
 You can declare a set with an array literal
 */
let sampleSet: Set = [1,2,3,4,1]
print(sampleSet)


/*:
 **NOTE:** sets only hold unique values - even though you added two `1`'s, only a single `1` appears in the collection.  Also note that we had to declare the type - inference will not work.  The syntax looks like an array to the compiler so it infers it as an array.
 */
/*:
 You can also declare a set using initializer syntax (and generic syntax)
 */
var initSet = Set<String>()
/*:
 ## Adding to a Set
 Use the `insert()` method to add items to a set
 */
var uniqueFinds: Set = ["Unicorn", "Bigfoot", "Stardust"]
uniqueFinds.insert("Leprechaun")
print(uniqueFinds)

/*:
 **NOTE:** items are not inserted in any recognizable order.  This is an unordered collection
 */
/*:
 ## Set Properties
 Use the `isEmpty` property to determine if a set is empty
 */
uniqueFinds.isEmpty

/*:
 Because sets are unordered and also unindexed, we are not able to ask for a particular item that we choose.  We are only able to **select a single item or all items**
 
 You can ask for the first element using the `first` property
 */
//refresh by running over and over
print(uniqueFinds.first)


/*:
 **NOTE:** this returns an optional value since there may not be a first value - and this does not provide any meaningful value since the set is unordered.
 */


/*:
 A loop is useful for looping over a set and getting each value stored inside
 */
for treasure in uniqueFinds{
    print(treasure)
}

/*:
 If you require a specific item, you can feed the set into an array initializer to create order in your set and then select via subscript or any other array property
 */

let uniqueArray = Array(uniqueFinds)
print(uniqueArray)
print(uniqueArray[0])

/*:
 ## Search Set Contents
 You can check the contents of a set to see if it `contains` a specific value
 */
uniqueFinds.contains("Bigfoot")
uniqueFinds.contains("bigfoot")

/*:
 **NOTE:** - this checks for equality of values - it is case sensitive.  So **B**igfoot is not the same as **b**igfoot.
 */
/*:
 ## Removing Items From a Set
 You can also remove elements from set use the `remove` method.
 This method also returns what was removed.
 */
var removedFind = uniqueFinds.remove("Bigfoot")
print(removedFind)


/*:
 You can also remove items from a set using the following two steps
 * first get the specific index of the item - with `firstIndexOf` method
 * use that index with the `removeAtIndex` method
 */

/*:
 **NOTE:** - the index is an optional - since there might not be an index.  The `!` is used for demonstration purposes only.  Do **NOT** do this in your code.  This is unsafe.  Use optional binding or other methods to ensure that optionals are safely unwrapped
 
 Also note - there are a number of instances where you will see code like this:
 */
/*:
 ## Comparing Sets
 The real power in sets comes from the ability to work with different groupings of information.  You can easily join sets together using the `union` method
 */
var myGrocery: Set = ["Apples", "Oranges", "Grapes"]
var yourGrocery: Set = ["Apples", "Bananas", "Kiwi"]

var fullList = myGrocery.union(yourGrocery)
fullList


/*:
 *Did you notice that we explicitly declared a Set - why?*
 */
/*:
 ## Intersecting Sets
 We can use the intersect method to tell where two sets *intersect* - to help us determine what both sides have in common.
 
 This returns a new set of just the common elements
 */
let commonGroceries = myGrocery.intersection(yourGrocery)
commonGroceries


/*:
 ## Subtracting Sets
 What if we wanted to see what remained if one collection was removed from the other?  We can use the  `subtracting` method for this
 */
let needToBuy = myGrocery.subtracting(yourGrocery)
needToBuy


/*:
 ## Supersets and Subsets
 Sometimes you may want to see if **all** of the items in one collection were included in another collection.  What you want to know is if one collection is a subset of another collection. (is the first collection all in the second)
 */
myGrocery.isSubset(of: yourGrocery)

/*:
 ## Disjointed Sets
 And finally - we want to know if one collection does not contain a single shared element.  We want to know if they are disjointed.
 */

myGrocery.isDisjoint(with: yourGrocery)



/*:
 ### Strings
 Strings are **collections** - they are *collections* of characters.
 
 As collections you can do this
 */
var word = "skywalker"
for letter in word{
    print("\(letter)")
}


/*:
 Can also use the `count` property to determine the number of characters in a string
 */
word.count

/*:
 Unfortunately, unlike an array - you cannot access a collection of characters using the subscript.
 */
//word[0]


/*:
 Remember a string is a represented by a collection of Unicode characters.  And some characters are actually made up of two Unicode characters.  This combination of characters is known as a grapheme cluster which is defined by the Unicode standard.
 */
let namev1 = "C\u{00E2}i"
let namev2 = "Ca\u{0302}i"
namev1.count
namev2.count
/*:
 You can access the Unicode scalars using the Unicode scalars view on the strings
 */
namev1.unicodeScalars.count
namev2.unicodeScalars.count


/*:
 And can also use a loop to iterate over the contents of a string's Unicode scalars
 */
for unicodeScalar in namev2.unicodeScalars {
    print(unicodeScalar)
}


/*:
 Because  a character can be made up of one or more Unicode values.  As can be shown above, this may involve iteration over Unicode scalar values that represent each character.  This makes it difficult to accurately return a subscript value for each character and is why it can't be indexed by integer values.
 
 Each String value has an associated *index type*.  The type is `String.index`.  This corresponds to the position of each `Character` in the string.
 
 There are properties available to help identify index values.  The `startIndex` property indicates the first index
 */
let firstIndex = namev1.startIndex
print(firstIndex)
/*:
 This index could then be used to obtain the first character in the string.
 */
let firstCharacter = namev1[firstIndex]



/*:
 This returns a Character type.  Character types are grapheme clusters.
 
 The last index can also be obtained using the `endIndex` property.
 */
let lastIndex = namev1.endIndex
print(lastIndex)
//let lastCharacter = namev1[lastIndex]


/*:
 The last index value is actually the position past the *last* character in the string.  If you attempt to get the character in the string...
 
 The `endIndex` isn't a valid argument to a string's subscript.  If a string is empty, the `endIndex` and `startIndex` properties are the same value
 */

var emptyString = ""
if emptyString.endIndex == emptyString.startIndex {
    print("The string is empty")
} else {
    print("This is not an empty string")
}


/*:
 What if you wanted to get the last character in a string?  You could make use of the `index(before: )` method.
 */
let newWord = "Rambo"
let endIndex = newWord.endIndex
let lastLetterIndex = newWord.index(before: endIndex)
let lastLetter = newWord[lastLetterIndex]



/*:
 We can also get the second letter in the word using the `index(after: )` method
 */

let startIndex = newWord.startIndex
let secondLetterIndex = newWord.index(after: startIndex)
let secondLetter = newWord[secondLetterIndex]


/*:
 Knowing a starting point index in a string - we can access values after that  using the `index(_ : offsetBy: )`
 */
// the word is Rambo
//let thirdLetterIndex = newWord.index(newWord.startIndex, offsetBy: 2)
let thirdLetterIndex = newWord.index(newWord.endIndex, offsetBy: -3)
let thirdLetter = newWord[thirdLetterIndex]


/*:
 **NOTE** - the startIndex, endIndex, index(before:), index(after:) and index(_: offsetBy:) can be used on any type that conforms to the Collection *protocol*
 
 String comparisons in Swift use a technique known as canonicalization - this means that they are converted to the same special character representation.  This could be to the single characters or to the combined characters.  Once this is complete  - it performs the comparison.  This is why the following are considered equal:
 */

if namev1 == namev2 {
    print("They are the same")
}


/*:
 This is also the same method that is used when counting the number of characters in a string.
 
 You can access all of the indices on a string by using the `indices` property.
 */

for indexValue in word.indices{
    print("This is the indexValue: - \(indexValue)")
    print("This is the letter \(word[indexValue])")
}


/*:
 ### Adding and removing characters
 Single characters can be inserted into a string at a specific index.  The `insert(_: at:)` method inserts a string at a specified index.
 */
var myName = "Batman"

myName.insert("!", at: myName.endIndex)



/*:
 Or you can insert string values into another string using the `insert(contentsOf: , at: )`
 */
myName.insert(contentsOf: "My name is ", at: myName.startIndex)




/*:
 To remove a character from a string at a specific location, use the `remove(at:)` method.
 */
let theLastLetterIndex = myName.index(before: myName.endIndex)
myName.remove(at: theLastLetterIndex)
myName
/*:
 ### Substrings
 You can access a portion of the string, or a substring, using the following:
 
 If you want to remove a substring, you can make use of the `removeSubrange(_:)` method.  This will remove a substring that falls within the following range
 */
myName
let range = myName.startIndex..<myName.index(myName.startIndex, offsetBy: 11)
myName.removeSubrange(range)
myName


/*:
 The insert, remove and removeSubrange methods can be used on any type that conforms to the `RangeReplaceableCollection` *protocol*.
 */
/*:
 You can also identify the index position of a specific letter - with some limitations.  Let's take a look at the following example:
 */
var lake = "erie"

let letterPosition = lake.firstIndex(of: "e")

if let letterPos = letterPosition {
    lake.remove(at: letterPos)
    print(lake)
}else {
    print("This letter could not be found")
}

/*:
 ### Open ended range
 You can declare an open-ended range - this type of range takes an index and assumes that the other end is the start or end of the collection.
 
 ..<10 is a range that includes all values from the start to the 9th
 
 8... is a range that includes all values from the 8th on
 */
/*:
 ### Reversing a String
 The reversed method can be used to reverse a string.
 */
var someWord = "abbaa"

let reversedWord = someWord.reversed()
print(reversedWord)

/*:
 **NOTE** this is not a string value, but rather a reversed collection (option + click on the reversed method to see what it returns)
 */
print(String(reversedWord))

/*:
 If you want a String - use the String initializer
 */

