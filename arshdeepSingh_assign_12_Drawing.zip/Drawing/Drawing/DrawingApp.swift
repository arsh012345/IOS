//
//  DrawingApp.swift
//  Drawing
//
//  Created by Arshdeep Singh on 2025-04-13.
//

import SwiftUI

@main
struct DrawingApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
