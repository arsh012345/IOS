//
//  My_Second_AppApp.swift
//  My Second App
//
//  Created by Arshdeep Singh on 2025-03-02.
//

import SwiftUI

@main
struct My_Second_AppApp: App {
    var body: some Scene {
        WindowGroup {
            MyView() //changed this to run my view
        }
    }
}
