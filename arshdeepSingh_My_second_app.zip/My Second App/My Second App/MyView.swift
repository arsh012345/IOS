//
//  MyView.swift
//  My Second App
//
//  Created by Arshdeep Singh on 2025-03-02.
//

import SwiftUI

struct MyView: View {
    @State private var alertAppear = false
    var body: some View {
        VStack{
                Image("arsh") //added my photo in new swiftview
                    .resizable()
                    .scaledToFit()
                    .clipShape(Circle())
                    .frame(width: 200, height: 200)
                
                Text("Arshdeep Singh")
                    .font(/*@START_MENU_TOKEN@*/.title/*@END_MENU_TOKEN@*/)
                    .fontWeight(.bold)
                    .multilineTextAlignment(.center)
                
                Divider()
                
                Text("My Program of Study is Computer Programming.")
                    .font(.subheadline)
                    .multilineTextAlignment(.leading)
                
            HStack{  //used hstack to put SF and text in one line
                    Image(systemName: "graduationcap.fill")  //SF symbol
                        .foregroundColor(Color.yellow)
                        .padding(.top)
                    
                    Text("My graduation year is 2025.")
                        .font(.subheadline)
                        .multilineTextAlignment(.leading)
                }
                
                Divider()
            VStack(alignment: .leading){ //using vstack to put lines in order
                Text("My desired career path is to become IOS app developer.")
                    .font(.body)
                    .multilineTextAlignment(.leading)
                
                Text("I have GPA: 3.5 and got second prize in website development in Web and App development Course.")
                    .font(.body)
                    .multilineTextAlignment(.leading)
                    .padding(.top, 1.0)
            }
            .padding(.horizontal)
            
            Spacer()
            
            Button{ //created button with Sf symbol and text
                alertAppear.toggle()
            }
            label:{
                Label("Favourite course", systemImage: "book.circle.fill")
            }
            
            .alert("My favourite course", isPresented: $alertAppear){
                Button("OK", role: .cancel){}
            }
            message:{
                Text("is Fundamentals of IOS development.")
            }
            
        }
    }
}

#Preview {
    MyView()
}
