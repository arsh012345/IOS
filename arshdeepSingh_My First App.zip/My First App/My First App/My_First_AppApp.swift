//
//  My_First_AppApp.swift
//  My First App
//
//  Created by Arshdeep Singh on 2025-02-12.
//

import SwiftUI

@main
struct My_First_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
