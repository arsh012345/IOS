//
//  ContentView.swift
//  My First App
//
//  Created by Arshdeep Singh on 2025-02-12.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        ZStack {
            let myBackground = Color("myBackground") //added background color using string
                myBackground
               .ignoresSafeArea()   //ignoresafearea to fill it in background
            VStack {
                Image("myPicture") //Added my own image here
                    .resizable()      //scaled to fit within its container
                    .aspectRatio(contentMode: .fit)
                //.clipShape(Capsule())   //comment out capsule
                    .clipShape(Circle())    //added circle clipshape
                
                Text("Arshdeep Singh")//Changed text to my name
                    .fontWeight(.heavy)//Changed font weight to heavy
                    .foregroundColor(Color.gray)//Changed font color to gray
                    .multilineTextAlignment(.center)//Made text center align
            }
            .padding()
        }
    }
}

#Preview {
    ContentView()
}
