//
//  ShowDetails.swift
//  MyShows
//
//  Created by Arshdeep Singh on 2025-03-30.
//

import SwiftUI

struct ShowDetails: View{
    let show: Show
    @EnvironmentObject var store: ShowSave         //calling environment object
    @State private var showAlert = false          //created button variable
    
    var body: some View {
        ScrollView {
               VStack{
                VStack{
                    AsyncImage(url: URL(string: show.artworkUrl100 ?? ""))
                        .frame(width: 120, height: 120)                      //Async Image used here again
                    
                    Text(show.trackName ?? "The Title")              //The title if no track name
                        .font(.title)
                        .bold()
                    
                    Text(show.collectionName ?? "No Name")         //collection name called
                        .font(.headline)
                }
                   
                Text(show.longDescription ?? show.shortDescription ?? "No description.")       //short desciption if no long one or no description massage
                    .padding(.vertical)
                Divider()
                   
                HStack{                              //Giving if show explicit or not
                    Image(systemName: show.trackExplicitness == "explicit" ? "exclamationmark.triangle.fill" : "figure.2.and.child.holdinghands")
                    Text(show.trackExplicitness ?? "")
                        .foregroundColor(show.trackExplicitness == "explicit" ? .red : .green)
                }
                Divider()
                   
                if let urlS = show.trackViewUrl, let url = URL(string: urlS) {
                        Link("For More Information click here", destination: url)      //using Link to open url Swift standard way
                            .font(.headline)
                            .foregroundColor(.blue)
                    }
                   
                Button("Add to Favourites") {
                    showAlert = true
                }
                .buttonStyle(.borderedProminent)
                .padding(.top)
            }
            .padding()
        }
        .navigationTitle("Details")
        .navigationBarTitleDisplayMode(.inline)
        .alert("Add to Favourites", isPresented: $showAlert){          //Add show to Favourites list logic
            Button("Add")
            {
                store.add(show:show)
            }
            Button("Cancel", role: .cancel){}
            }
         message: {
            Text(show.trackName ?? "")
        }
    }
}
