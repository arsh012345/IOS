//
//  ShowData.swift
//  MyShows
//
//  Created by Arshdeep Singh on 2025-03-30.
//

import Foundation

struct Show: Codable, Hashable, Identifiable {
    var id: Int { trackId }             //made id as unique identifier
    
    let trackId: Int
    let trackName: String?
    let collectionName: String?            //variables defines with datatypes
    let primaryGenreName: String?
    let artworkUrl100: String?
    let trackExplicitness: String?
    let trackViewUrl:String?
    let shortDescription: String?
    let longDescription: String?
}

struct ShowExtract: Codable {                  //ShowExtract for codable use in decoding
    let resultCount: Int
    let results: [Show]
}
