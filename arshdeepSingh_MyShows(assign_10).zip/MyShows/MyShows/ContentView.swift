//
//  ContentView.swift
//  MyShows
//
//  Created by Arshdeep Singh on 2025-03-30.
//

import SwiftUI

struct ContentView: View {
    @EnvironmentObject var store: ShowSave    //calling object for badge
    var body: some View {              //using tab view
        TabView{
            NavigationStack{
                AllShows()
            }
            .tabItem{
                Label("Search", systemImage: "magnifyingglass")
            }
            NavigationStack{
                FavouritesList()
            }
            .tabItem{
                Label("Favourites", systemImage: "heart")
            }
            .badge(store.favoriteList.count)     //added badge for Good interface
        }
    }
}

#Preview {
    ContentView()
        .environmentObject(ShowSave())
}
