//
//  AllShows.swift
//  MyShows
//
//  Created by Arshdeep Singh on 2025-03-30.
//

import SwiftUI

struct AllShows: View{
    @StateObject private var showView = ShowFetch()        //calling ShowFetch here
    @EnvironmentObject var store: ShowSave                 //Environment object ShowSave
    @State private var searchShow = ""
    
    let columns = [GridItem(.adaptive(minimum: 100), spacing: 12)]  //grid columns made here
    
    var body: some View {
        VStack{
            TextField("Enter a show name to search", text: $searchShow)
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding()
                .onSubmit           //onsubmit calls loadData in ShowFetch
                {
                    showView.loadData(forSearch: searchShow)
                }
            
        ScrollView{
            LazyVGrid(columns: columns, spacing: 16){
                ForEach(showView.shows) { show in
                    NavigationLink(destination: ShowDetails(show: show)) {
                        VStack{
                            AsyncImage(url: URL(string: show.artworkUrl100 ?? ""))  //using AsyncImage here and unwraping it
                                .frame(width: 100, height: 100)
                                .aspectRatio(contentMode: .fill)
                                .cornerRadius(8)
                            
                            Text(show.trackName ?? "")        //Trackname with unwrapping
                                .font(.caption)
                                .multilineTextAlignment(.leading)
                                .lineLimit(2)
                                .padding(.all)
                                .frame(width:120, height: 32)
                        }
                        .background(Color.green)
                        .cornerRadius(10)
                        .frame(width: 100, height: 100)
                        .padding(.all)
                     }
                   }
                }
                .padding()
            }
        }
        .onAppear{                         //using onAppear as used in CampSite app for prefill of grid with my favorite show
            if showView.shows.isEmpty
            {
              showView.loadData(forSearch: "Breaking Bad")
            }
        }
    }
}

#Preview {
    AllShows()
}
