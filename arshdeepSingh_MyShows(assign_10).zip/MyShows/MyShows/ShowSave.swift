//
//  ShowSave.swift
//  MyShows
//
//  Created by Arshdeep Singh on 2025-03-30.
//

import Foundation

class ShowSave: ObservableObject {                      //made observable object like we taught
    @Published var favoriteList: [Show] = []              //using published from presistence pdf
    
    private let saving = FileManager.documentsDirectory.appendingPathComponent("savelist.json")
    init() {                                                    //save json file here
        load()
    }
    
    func add(show: Show) {
        if !favoriteList.contains(show){            //add function for show adding in save
            favoriteList.append(show)
            save()
        }
    }
    
    func remove(show: Show) {
        if let index = favoriteList.firstIndex(of: show){     //remove function for removal by index
            favoriteList.remove(at: index)
            save()
        }
    }
    
    private func save(){
        if let encoded = try? JSONEncoder().encode(favoriteList){    //save for file saving
            try? encoded.write(to: saving)
        }
    }
    
    private func load(){                                    //load for file loading
        if let data = try? Data(contentsOf: saving),
           let decoding = try? JSONDecoder().decode([Show].self, from: data){
            favoriteList = decoding
        }
    }
}

//extension for FileManager path
extension FileManager{
    static var documentsDirectory: URL {
        FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
    }
}

