//
//  MyShowsApp.swift
//  MyShows
//
//  Created by Arshdeep Singh on 2025-03-30.
//

import SwiftUI

@main
struct MyShowsApp: App {
    @StateObject private var store = ShowSave()
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
        }
    }
}
