//
//  FavouritesList.swift
//  MyShows
//
//  Created by Arshdeep Singh on 2025-03-30.
//

import SwiftUI

struct FavouritesList: View {
    @EnvironmentObject var store: ShowSave            //evironment object called here again
    
    var body: some View {
        List{
            ForEach(store.favoriteList){ show in
                VStack(alignment: .leading){
                    Text(show.trackName ?? "Unknown Episode")      //episode name and show name here
                        .font(.headline)
                    Text(show.collectionName ?? "No Name")
                        .font(.subheadline)
                }
            }
            .onDelete{indexSet in                   //using onDelete like used in campsite project
                for index in indexSet{
                    let show = store.favoriteList[index]
                    store.remove(show: show)
                }
            }
            .navigationTitle("Favourites - \(store.favoriteList.count) \(store.favoriteList.count == 1 ? "Show" : "Shows")")  //simple logic for watchlist count
        }
    }
}
