//
//  ShowFetch.swift
//  MyShows
//
//  Created by Arshdeep Singh on 2025-03-30.
//

import Foundation

class ShowFetch: ObservableObject{
    @Published var shows: [Show] = []
    
    func loadData(forSearch searchShow: String){
        Task{                         //using encoded same like campsite but using queryAllowed instead urlAllowed because we using query
            guard let allShows = searchShow.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed),
                  let url = URL(string: "https://itunes.apple.com/search?term=\(allShows)&media=tvShow")
            else
            {
                return
            }
            
            do{                     //decodeing here same as learned
                let (data, _) = try await URLSession.shared.data(from: url)
                let decoder = JSONDecoder()               //putting decoder in variable
                let result = try decoder.decode(ShowExtract.self, from: data)
                shows = result.results
            }
            catch
            {
                print("Error in fetching: \(error.localizedDescription)")  //error if featching won't happens
            }
        }
    }
}
