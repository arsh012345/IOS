import UIKit

/*:
This is a Swift Playground file. If you see a series of comments, turn this into rendered code by clicking on Editor > at the bottom of the Editor menu choose Show Rendered Markup
 */
/*:
 # Swift Introduction - Week 1
 ### Variables and named constants
* Programming languages use memory locations to store information.
 * Depending on the programming language, you may have to declare the type of data that the variable represents. (Weakly typed languages do not require a type – Strongly typed do)
 * Declaring a type and explicitly stating the type can be done - however with Swift there is a better way - it uses *type inference*.
 * There are ways to store values - one as a variable and one as a constant.
 * Declare variables using the keyword `var`
 * Constants represent values that will not change.  Constants are declared using the keyword `let`.
 * Names are written by convention using camelCase.  For example if you wanted to store a person’s name you would declare that the variable `firstName`
 * String variables can store any text data – single characters, collection of characters (including numeric) and an “empty string”
 * Numeric variables can store any type of  number – with or without decimal places
 * The syntax for declaring variables or constants where no value is being assigned looks like this:  `name:type` - where `name` is the variable or constant name (no difference between the two) followed by `:` followed by the type of information being stored.
 
*/
//declare a variable to hold a person's name - explicitly declaring the type
var personName:String = "Bob"


//declare a constant that will hold the maximum number of retrys - explicitly declaring the type
let numAttempts: Int = 3

/*:
### Type Inference
With Swift, we will make use of type inference when assigning a value.  Swift is very good at detecting what type of information you are working with, based on the value that is being assigned.
 * Explicitly describing types is not always required in Swift - usually only required when you are not providing a value
 * The Swift compiler is able to infer the data type
 * Type inference allows for the removal of the redundancy of explicitly declaring a type
 * When assigning a value to a variable, Swift can infer what the appropriate data type is
 */
//declare a variable to hold a person's name using inference
var inferredName = "Bob"


//declare a constant to hold the maximum number of retrys using inference
let attempts = 3

/*:
 When combining literal values, the compiler will infer what types based on the context
 */
let integer = 5
let stringValue = "6"
let double = 6.6
//var sum = a + b
//var sum = a + c
var result = integer / 2

/*:
 Reveal the type by choosing Option + clicking on it
 */
/*:
 But why a double and not a float.  Swift infers a Double - and it suggests that for most cases a Double is the preferred data type.  If you require a Float, then you would have to explicitly declare this.  See below for more information on types.
 */
/*:
 ### Type Conversion
 The compiler will enforce type safety. It will not allow you to add two different types together.  To see the results, remove the // from in front of `sum = integer + double` and run the playground.  It will give you and error.  You can't fool it - even if you tried the same thing with the `sum = integer + anotherDouble`.
 */




//sumOfNumbers = integer + double

/*:
 ## Types
 ### Integers
 * Integers are whole numbers with no fractional component
 * Integers are either signed (positive, negative or zero) or unsigned (positive or zero)
 * Swift provides signed and unsigned integers in 8, 16, 32 and 64 bit forms
 In most cases you don’t need to pick a specific size of integer
 * Swift provides an integer type Int which is the size of the current platform’s native word size
 * On a 32bit platform it is an `Int32`
 * On a 64bit platform it is an `Int64`
 **NOTE** – unless you require a specific size integer, use Int for values in your code
 
 **NOTE**: it is recommended that you only use an UInt when you specifically need an unsigned integer type.
 */
/*:
 *"Use UInt only when you specifically need an unsigned integer type with the same size as the platform’s native word size. If this isn’t the case, Int is preferred, even when the values to be stored are known to be nonnegative. A consistent use of Int for integer values aids code interoperability, avoids the need to convert between different number types, and matches integer type inference, as described in [Type Safety and Type Inference](https://docs.swift.org/swift-book/documentation/the-swift-programming-language/thebasics/#Type-Safety-and-Type-Inference)."*
 */
/*:
 ### Floating Point Numbers
 Floating point numbers are used to represent numbers that contain a decimal (numbers with a fractional component)
 * Represent a much wider range of values than integer types and can store numbers that are smaller than an `Int`
 
 There are two types
 * `Double` – represents a 64-bit number – has a precision of at least 15 decimal digits
 * `Float` – represents a 32-bit number – store as little as 6 decimal digits
 
 A double has twice the level of precision as a float – hence the name double.
 
 **NOTE:**  where either type would be appropriate, `Double` is preferred
 */
/*:
 Large numbers can be difficult to read
 Placing a comma for readability is not allowed
 */
let hardToReadLargeValue = 1000000000000
let largeValueReadable = 1_000_000_000_000

/*:
 Use underscores for clarity – does not affect the value of the literal, but makes it easier to read
 */
/*:
 ###  Numeric Operations
 Numeric calculations use arithmetic operators:
 * `+`  for addition
 * `-` for subtraction
 * `*` for multiplication
 * `/` for division
 * `%` for modulus
 
 In most languages operations are carried out in this order:
 * Exponential operations performed before any basic arithmetic operation
 * Multiplication and division
 * Addition and subtraction
 * **BEDMAS**
 */
/*:
 ### Increasing and Decreasing Numbers
 For example – you want to increase a numeric variable by 1
 */
var startingValue = 1
startingValue = startingValue + 1


/*:
 We can use a shorthand version where we combine the `+` and `=` to `+=`
 */
startingValue += 1
var myNumber = 5
myNumber *= 1


/*:
 Or to decrease the value
 */
startingValue -= 1



/*:
 **There is no ++ operator**
 */
/*:
 ### Printing Results to the Console
 The print function allows us to display formatted text in the console.
 
 ![printDetails](printFunctionDetails.png)
 */
/*:
 **Do not** provide a print statement with multiple variables, separated by columns.  **This is important to remember and will cost marks on assignments**
 */
var name = "Obi-Wan Kenobi"
print(name)

/*:
 ### Program Comments
 * For single line comments use //
 * For multi-line coments use \/ * * \/
                                
 */
/*:
 #### Unicode
 Unicode characters can be represented in Swift using the specified Unicode value.  For example, take a look at the following chart:
 
 ![Dingbats chart from Unicode](Dingbats.png)
 If we wanted to add that arrow character we would use `\u{n}` in Swift where n is the hexadecimal code
 */
print("\u{2702}")
/*:
 Swift also allows you to use emojis and symbols as variable names (to access emojis, select Edit at the top and then Emoji & Symbols)
 */
let 🐶 = "Sasha"
print(🐶)


/*:
 Fun to do - but **don't do it**!  This makes you code terrible to support and work with!
 */

/*:
 ### Concatenation
 Concatenation uses the addition operator (+) to join the two strings together.
 It literally joins two strings together - it will **not** add any space between the two literals being joined.
 Strings can be added together using the addition operator (+)
 */
let firstWord = "Oh no"
let secondWord = "on the screen"
let exampleSentence = firstWord + secondWord



/*:
 You can also append a string value to and *existing* string variable with the addition assignment operator (+=)
 */
var sentence = ""
sentence += firstWord
sentence += secondWord
/*:
 ### String Interpolation
 * Strings can also be built using interpolation and it is a much cleaner method for building strings
 * Interpolation places the variable in a string as a placeholder – this tells Swift to replace the placeholder with the actual value
 * It is more readable than concatenation – you see exactly what result you will get before compiling
    * With concatenation it is often difficult to see the output before running and errors are noticed once the output is displayed
 * Format for string interpolation is `\(n)` where `n` is the variable or constant name
 ### IMPORTANT:
 **String interpolation is the preferred method for formatting and joining strings - including in the print statement**
 */

print("Help me \(name), you are my only hope.")
print("\(firstWord), \(secondWord)")
/*:
 ### Multi-line Strings
 * If you need strings to span several lines, use a multiline string literal
 * The characters are surrounded by three double quotes
 * All code will line up with the level of indentation **PRIOR** to  the closing `“””`
 */
var openingCrawl = """
    It is a period of civil war.
    Rebel spaceships, striking
    from a hidden base, have won
    their first victory against
    the evil Galactic Empire.
    
    During the battle, Rebel
    spies managed to steal secret
    plans to the Empire's
    ultimate weapon, the DEATH
    STAR, an armored space
    station with enough power to
    destroy an entire planet.
    
    Pursued by the Empire's
    sinister agents, Princess
    Leia races home aboard her
    starship, custodian of the
    stolen plans that can save
    her people and restore
    freedom to the galaxy.....
    """
print(openingCrawl)

/*:
 Indentation determines how the information will be displayed.
 */

/*:
 ### Tuples
 * Tuples group multiple values into a single, compound value
 * The grouped values can be of **any type** – they can even be **different types**
 * This allows for creation of simple groups of related values and allows for the *return* of multiple values where other languages only allow a single value
 * The syntax for a basic tuple is
 `(someValue, someValue, ...)`
 */
/*:
 Tuples can contain the same type of information
 */
var flightDetails = ("DTW","MCO")

/*:
 Or the tuples can be of different types
 */
var differentFlightDetails = ("DTW", "MCO", 5)


/*:
 ### Decomposing Tuples
 * Decomposing a tuple means extracting the values into separate constants or variables
 * Values are stored in an ordered manner – the first value can be accessed by its position
 * Tuples use zero indexing – the first position is at index 0 not 1
 * Decomposing or extracting the values from a tuple can be achieved in several ways
 * Explicitly assign to variables or constants
 */
let (departure,arrivals) = flightDetails
print(departure)
print(arrivals)

/*:
 Or tuples can be accessed using their index value
 */
flightDetails.0
flightDetails.1


/*:
 However using an index is not intuitive - 0 has no meaning it simply means the first item.
 Instead assign names to the individual elements inside of the tuple
 */
let completeFlightDetails = (departure: "DTW", arrival: "MCO")
completeFlightDetails.departure
completeFlightDetails.arrival


/*:
 You may need to access a specific element in a tuple, and ignore the rest
 * The underscore is often used to meet the requirements of the compiler, but not waste using a memory location for a value that you will never require
 */
let (_,_,numTickets) = differentFlightDetails
print(numTickets)

/*:
* Tuples are especially useful as return types for functions
* Can return more than just a single value of a single type
* Not meant for the creation of complex data structures that need to persist beyond a temporary scope
 */
/*:
 # Control Structures
 ### If/Else Statements
 * Here is the syntax for a basic conditional statement
 **NOTE:** - there are no ( ) around the condition
 */
var currentSpeed = 80
if currentSpeed >= 80{
    print("Slow down!")
}


/*:
 The if/else syntax
 */
if currentSpeed > 80{
    print("Slow down")
} else {
    print("Carry-on!")
}

/*:
 ### Comparison Operators
 ![Comparison Operators](comparisonOperators.png)
 */
/*:
 ### Logical Operators
 ![Logical Operators](logicalOperators.png)
 */
/*:
 ### Ternary Operator
 Ternary conditional operator is a special operator with three parts
 
 Syntax follows :
 
 `Question ? Answer1 :  Answer 2`
 
 If the question is true, then it returns whatever is represented by answer 1 and otherwise it returns whatever is represented by answer 2.
 This is shorthand code for
 
                 if question {
                    answer1
                 } else {
                    answer2
                 }

 
 If the lines of code start to wrap it is best to not use the ternary operator
 
 **NOTE** – the ternary operator can be hard to read.  Avoid combining multiple instances of the ternary operator
 */
print(currentSpeed >= 80 ? "Slow Down!" : "Carry on!")


/*:
 ### For-in Loops
 A for-in loop is used to iterate over a sequence
 */
for i in 1...100{
    print(i)
}


/*:
 The constant `i` represents the current value of the iterator
 This only exists inside the body of the loop - between the {}
 */
/*:
If you do not need the value it can be ignored using an underscore (_)
 */
for _ in 1...3{
    print("Beetlejuice!")
}

/*:
 ### Type Inference in Loops
 `For` loops utilize type inference to identify the value type of the variable
 * This reduces the possibility of error
 */
/*:
 ### While loops
 */
var counter = 1
while counter < 6{
    print("Your number is \(counter)")
    counter += 1
}



/*:
 ### Repeat-while loops
 * Similar to `do-while` loops in other languages
 */
var nextCounter = 1
repeat{
    print("Your number is \(nextCounter)")
    nextCounter += 1
} while nextCounter < 6

/*:
 ### Switch
 * Every switch statement **MUST** be exhaustive – every possible case must be considered and must be a case
 * If it is not possible to provide every possible option, then a default value (indicated with the keyword `default`) is provided
 * Breaks are **not required** - the code does not automatically fallthrough.  They are only required if there is an absence of code in your case.
 */
var randomValue = 0

switch randomValue{
case 0:
    print("You guessed the random value")
default:
////    print("You did not guess the random value")
    break
}



/*:
 The body of each case **MUST** contain at least one executable statement

 */
/*:
 Multiple matches for a single case can be separated by commas
 */
var monster = "Mummy"
switch monster{
case "Wolfman", "Dracula", "Mummy":
    print("Universal movie monster")
//    fallthrough
case "Mothra", "Godzilla", "Gamera":
    print("Japanese Movie Monster")
default:
    print("Don't know")
}


/*:
 ### Ranges
 Switch statement can make use of range operators
 
 Closed range operator (…) – an inclusive list including the value to the left and the value to the right (note the three dots)
 
 `case 1...5: //is the value 1,2,3,4 or 5`
 
 Half-open range operator (..<) – this is a list of values starting with the value to the left and ending before the value on the right (does NOT include the right hand value)
 
 `case 1..<5: //is the value 1,2,3 or 4`
 
 */
/*:
 # Functions
 ### Basic Functions
 A function is defined with the keyword `func`
 
 Parentheses wrap arguments – which are optional
 
 An opening **{** defines the beginning of the function and a **}** denotes the close or end of the function
 
 **NOTE** – in Swift the { and } are required for all functions, even if the function code is a single line
 */
/*:
 ### Function Parameters
 * Parameters provide input to the functions
 * An argument is the *value* that a caller gives to the function’s parameters
 * Arguments that are provided to the function must match the type that is defined.
 * A function can take as many parameters as required to perform its task.  The parameters are all defined with a type and separated with a ,
 */
func simplePage (name: String, to: String){
    print("Paging \(name), please report to \(to)")
}


func pagingOfficer(officerName name: String, toLocation to: String){
    print("Paging \(name), please report to \(to)")
}

pagingOfficer(officerName: "Bob", toLocation: "Engineering")
 

/*:
 ### Parameter Names
 Sometimes it is useful to have all of a function’s parameter named
 * This makes your functions more readable
 * The external parameter names are used when *calling* the function
 * The internal parameter names are used *inside* the function
 */

//pagingOfficer(officerName officer: <#T##String#>, toLocation location: <#T##String#>)


/*:
 As you can see in the above code - calling the function you use the external names
 
 ![function with external names](externalNames.png)
 
 And use internal names when working with the code *in* the function
 
 ![function use with internal names](internalNames.png)
 */
/*:
 ### Default Parameter Values
 * Default values should be put at the end of the parameter list
 * Default values are written using the assignment operator
 * Call the function and pass no values to use the default value
 * Call the function and pass a value to override the default value
 */

func setWarpSpeed(warpSpeed: Double = 2){
    print("Setting warp to \(warpSpeed)")
}

setWarpSpeed()
setWarpSpeed(warpSpeed: 3.4)

/*:
 You can now call this function two different ways
 
  
 */
/*:
 ### Omitting External Parameter Names
 If you do not want to use an external parameter name for any parameter you can simply use an _ in its place.  This is **NOT** recommended as it makes your function more difficult to understand.  Use with appropriate function naming - for example:
 */
/*:
 ### Returning from a function
 All functions return a value
 * If no return type is defined, the function returns a value of type Void an empty tuple with zero elements – `()`
 To specify a return value you include the return arrow (`->`) and a return type
 * Multiple lines of code require the use of the keyword `return`.  If the body of the function is only made of a single line, the `return` keyward may be omitted.
 */

func addTwoNumbers(firstNumber: Int, secondNumber: Int) -> (Int, Int, Int) {
     (firstNumber, secondNumber, firstNumber + secondNumber)
}
//
//func addTwoNumbers(firstNumber: Int, secondNumber: Int) ->  Int{
//     firstNumber + secondNumber
//}
//
//let sumVal = addTwoNumbers(firstNumber: 1, secondNumber: 1)
//sumVal.0

/*:
 Return values can be ignored – but a function set to return a value must always return the value.
 * Attempting to allow control to fall out the bottom of the function without returning a value will result in a compile-time error
 */
/*:
 ### Nested Functions and Scope
 Functions can be defined within the bodies of other functions (nested functions
 * Nested functions are hidden from code outside the function it is nested in
 * An enclosing function can also return one of its nested functions to allow the nested function to be used in another scope
 * Useful when you want to hide or isolate parts of your code
 */
/*:
 ### Multiple Returns
 Functions return a **single** value
 
 Functions that return a *tuple* type as the return type are able to return *multiple values* as a single compound return value
 */
/*:
 ### Function Types
 Every function has a specific function type – made up of the parameter types and the return type of the function
 */
//use option click to see the type of function
func something(name: String) -> Int {
    return 1
}




/*:
 The type of this function is `(String) -> Int`
 
 ![Example of return type](returnTypes.png)
 */
/*:
 This is an example of no parameters or return value.
 */
func printOut(){
    print("Hello")
}
/*:
 ![Return Void Example](returnVoid.png)
 This is a return type of `() -> Void`
 */
/*:
 Function types can be used exactly like any other *type*.
 */
/*:
 ### Function Types as Parameters
 Function types can be passed as parameters for another function
 */

let sumVal1 = addTwoNumbers(firstNumber: 1, secondNumber: 1)


func betterMath(mathFunc: (Int, Int) -> Int, mathCalculation: String, firstNum: Int, secondNum: Int)-> String{
    "Performing \(mathCalculation) on \(firstNum) and \(secondNum) to get \(mathFunc(firstNum, secondNum))"
}

func multiplyNum(firstNumber: Int, secondNumber: Int) -> Int{
    firstNumber * secondNumber
}

func addNum(first: Int, second: Int)-> Int{
    first + second
}

print(betterMath(mathFunc: multiplyNum, mathCalculation: "Multiply", firstNum: 2, secondNum: 4))
print(betterMath(mathFunc: addNum, mathCalculation: "Addition", firstNum: 7, secondNum: 8))




/*:
 **NOTE** the absence of the () - when you use the () this means to call it
 */
