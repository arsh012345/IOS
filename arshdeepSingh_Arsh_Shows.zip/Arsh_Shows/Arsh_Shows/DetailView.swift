//
//  DetailView.swift
//  Arsh_Shows
//
//  Created by Arshdeep Singh on 2025-03-23.
//

import SwiftUI

struct DetailView: View {
    let show: TVShow
    
    var body: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 16) {
                Text(show.trackName ?? "No Name of show")              //title name on top
                    .font(.title)
                    .bold()

                AsyncImage(url: URL(string: show.artworkUrl100 ?? "")) { image in
                    image.resizable()                         //artwork in asyncimage
                } placeholder: {
                    Color.gray
                }
                .frame(width: 200, height: 200)
                .cornerRadius(12)
                .clipShape(Circle())

                Text("Show: \(show.collectionName ?? "Not given")")
                    .font(.headline)

                Text(show.longDescription ?? "No Description")
                    .font(.body)

                HStack {
                    Image(systemName: (show.trackExplicitness == "explicit") ? "exclamationmark.triangle.fill" : "checkmark.seal.fill")                                        //if show is explicit image will appear
                        .foregroundColor((show.trackExplicitness == "explicit") ? .red : .green)
                    Text(show.trackExplicitness?.capitalized ?? "")
                }
                
                if let urlS = show.trackViewUrl, let url = URL(string: urlS) {
                    Link("See More Show Information", destination: url)               //url link to show more info
                        .font(.headline)
                        .foregroundColor(.blue)
                }
                Spacer()
            }
            .padding()
        }
    }
}
