//
//  TVShowView.swift
//  Arsh_Shows
//
//  Created by Arshdeep Singh on 2025-03-23.
//
import Foundation

class TVShowView: ObservableObject {
    @Published var shows: [TVShow] = []   //TVShow array created here
    
    func loadShows() {
        shows = Bundle.main.decodeTVShows("myShows")  //calling json file here to view it
    }
}
