//
//  TVShowData.swift
//  Arsh_Shows
//
//  Created by Arshdeep Singh on 2025-03-23.
//
import Foundation

struct TVShow: Codable, Hashable, Identifiable {
    var id: Int { trackId }         //main id for json data
    let trackId: Int
    let artistName: String?
    let collectionName: String?
    let trackName: String?
    let artworkUrl100: String?               //artworkUrl for show thumbnail
    let shortDescription: String?
    let longDescription: String?
    let trackExplicitness: String?
    let trackViewUrl: String?
}
struct TVShowExtract: Codable {              //codable used to extract json file
    let resultCount: Int
    let results: [TVShow]
}

extension Bundle {
    func decodeTVShows(_ file: String) -> [TVShow] {
        guard let url = self.url(forResource: file, withExtension: "json") else {
            fatalError("did not found json file")               //error if json file not found
        }
        
        guard let data = try? Data(contentsOf: url) else {
            fatalError("Can not load data from json you provided")        //error if json file not loaded
        }
        
        let decoder = JSONDecoder()       //decoder put in variable
        guard let shows = try? decoder.decode(TVShowExtract.self, from: data) else {
            fatalError("did not able to decode json file")                //error if decoding json not happens
        }
        return shows.results
    }
}
