//
//  ContentView.swift
//  Arsh_Shows
//
//  Created by Arshdeep Singh on 2025-03-23.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView{
            TVShowListView()      //added TVShowListView here
        }
    }
}

#Preview {
    ContentView()
}
