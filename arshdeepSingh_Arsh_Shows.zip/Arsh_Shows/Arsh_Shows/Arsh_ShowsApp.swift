//
//  Arsh_ShowsApp.swift
//  Arsh_Shows
//
//  Created by Arshdeep Singh on 2025-03-23.
//

import SwiftUI

@main
struct Arsh_ShowsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
