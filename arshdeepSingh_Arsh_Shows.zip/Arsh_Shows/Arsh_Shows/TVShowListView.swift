//
//  TVShowListView.swift
//  Arsh_Shows
//
//  Created by Arshdeep Singh on 2025-03-23.
//

import SwiftUI

struct TVShowListView: View {
    @StateObject private var viewModel = TVShowView()   //calling TVShowView here
    @State private var searchT = ""            //searchT variable for show search logic
    
       var filtering: [TVShow] {                //filtering variable for search bar
           if searchT.isEmpty {
               return viewModel.shows
           } else {
               return viewModel.shows.filter {
                   ($0.trackName ?? "").localizedCaseInsensitiveContains(searchT) || ($0.collectionName ?? "").localizedCaseInsensitiveContains(searchT)
               }
           }
       }
    
    var body: some View {
        VStack {
            Text("Arsh's Shows")           //main title of app
                .font(.largeTitle)
                .bold()
                .padding(.top)
            
            TextField("Search", text: $searchT)              //created search bar here
                .textFieldStyle(RoundedBorderTextFieldStyle())
                .padding(.all)
            
            List(filtering) { show in
                NavigationLink(destination: DetailView(show: show))  //detail view for detail of each show in list
                {
                    HStack(alignment: .top) {
                        AsyncImage(url: URL(string: show.artworkUrl100 ?? "")) { image in
                            image.resizable()       //async image used for artwork here
                        }
                        placeholder: {
                            Color.gray
                        }
                        .frame(width: 50, height: 50)
                        .cornerRadius(7)

                        VStack(alignment: .leading) {
                            Text(show.collectionName ?? "Show is Unknown")
                                .font(.headline)
                            Text(show.trackName ?? "Unknown Episode Name")
                                .font(.subheadline)
                                .foregroundColor(.secondary)
                            Text(show.shortDescription ?? "No description")
                                .lineLimit(2)
                                .font(.caption)
                        }
                    }
                    .padding(.vertical, 5)
                }
            }
            .onAppear {
                viewModel.loadShows()
            }
        }
        .navigationBarHidden(true)
    }
}

#Preview
{
    TVShowListView()
}
